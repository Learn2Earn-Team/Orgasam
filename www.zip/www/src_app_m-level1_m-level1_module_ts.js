(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_m-level1_m-level1_module_ts"],{

/***/ 3880:
/*!*****************************************************!*\
  !*** ./src/app/m-level1/m-level1-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel1PageRoutingModule": () => (/* binding */ MLevel1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _m_level1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level1.page */ 7289);




const routes = [
    {
        path: '',
        component: _m_level1_page__WEBPACK_IMPORTED_MODULE_0__.MLevel1Page
    }
];
let MLevel1PageRoutingModule = class MLevel1PageRoutingModule {
};
MLevel1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MLevel1PageRoutingModule);



/***/ }),

/***/ 9382:
/*!*********************************************!*\
  !*** ./src/app/m-level1/m-level1.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel1PageModule": () => (/* binding */ MLevel1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _m_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level1-routing.module */ 3880);
/* harmony import */ var _m_level1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level1.page */ 7289);







let MLevel1PageModule = class MLevel1PageModule {
};
MLevel1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _m_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__.MLevel1PageRoutingModule
        ],
        declarations: [_m_level1_page__WEBPACK_IMPORTED_MODULE_1__.MLevel1Page]
    })
], MLevel1PageModule);



/***/ }),

/***/ 7289:
/*!*******************************************!*\
  !*** ./src/app/m-level1/m-level1.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel1Page": () => (/* binding */ MLevel1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_m_level1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./m-level1.page.html */ 8016);
/* harmony import */ var _m_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level1.page.scss */ 282);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let MLevel1Page = class MLevel1Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['m-level2']);
    }
};
MLevel1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
MLevel1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-m-level1',
        template: _raw_loader_m_level1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_m_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MLevel1Page);



/***/ }),

/***/ 282:
/*!*********************************************!*\
  !*** ./src/app/m-level1/m-level1.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pur.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #7A3E6A;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E3D3D5;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E3D3D5;\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  text-align: center;\n  justify-content: center;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.iput {\n  width: 70px;\n}\n\n.iput1 {\n  margin-right: 50px;\n}\n\n.row12 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row13 {\n  margin-top: -5px;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm0tbGV2ZWwxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUVJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUFOOztBQUVJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRk47O0FBUUU7RUFDRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UseUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBSE47O0FBTUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBSEY7O0FBT0U7RUFDQyxnQkFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7QUFMSDs7QUFRRTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQUxKOztBQU9FO0VBQ0UsV0FBQTtBQUpKOztBQVFFO0VBQ0Esa0JBQUE7QUFMRjs7QUFPRTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7QUFKSjs7QUFPRTtFQUdFLGdCQUFBO0FBTko7O0FBVUU7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBUEYiLCJmaWxlIjoibS1sZXZlbDEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgcHVyLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG5cclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICM3QTNFNkE7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiAgICAubGFibHtcclxuXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10gKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIG1hcmdpbjogMCAwLjVlbTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0RDMzQ2MTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzEgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8yICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMyArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yb3cze1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG4gICAgYmFja2dyb3VuZDogI0UzRDNENTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzR7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTNEM0Q1O1xyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAuYnRuIHtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICB9XHJcbiAgLnJvdzh7XHJcbiAgIG1hcmdpbi10b3A6IDE1cHg7XHJcblxyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgaW9uLWlucHV0IHtcclxuICAgIGhlaWdodDogMjBweDtcclxuICAgIGJhY2tncm91bmQ6cmdiKDI1NSwgMjU1LCAyNTUpXHJcbiAgfVxyXG4gIC5pcHV0e1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcblxyXG5cclxuICB9XHJcbiAgLmlwdXQxe1xyXG4gIG1hcmdpbi1yaWdodDogNTBweDtcclxuICB9XHJcbiAgLnJvdzEye1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAucm93MTN7XHJcblxyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuXHJcbiAgLnRleHQxe1xyXG4gIHBhZGRpbmctbGVmdDogNTBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiA1MHB4O1xyXG4gIH1cclxuXHJcblxyXG5cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 8016:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/m-level1/m-level1.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logopr.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n    <ion-row>\n      <img style=\"width: 100%;\" src=\"../../assets/level/m-level1.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te has masturbado alguna vez?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m1r1\">SI</label>\n        <input id=\"m1r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n        <label for=\"m1r2\">NO</label>\n        <input id=\"m1r2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n        <label for=\"m1r2\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que partes de tu cuerpo te gustan mas que te toquen?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n      </ion-col>\n\n      <ion-col style=\"margin-right: 60px;\">\n\n        <ion-input class=\"iput\"></ion-input>\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Que partes de tu cuerpo te gustan mas que te besen? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n      </ion-col>\n\n      <ion-col style=\"margin-right: 60px;\">\n\n        <ion-input class=\"iput\"></ion-input>\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Sueles usar juguetes eróticos? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n        <label for=\"m1r6\">SI</label>\n        <input id=\"m1r6\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"m1r7\">NO</label>\n        <input id=\"m1r7\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"m1r7\"></label>\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te gusta que te aten en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m1r9\">SI</label>\n        <input id=\"m1r9\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"m1r10\">NO</label>\n        <input id=\"m1r10\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"m1r10\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Te gusta usar las esposas?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"m1r12\">SI</label>\n        <input id=\"m1r12\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"m1r14\">NO</label>\n        <input id=\"m1r14\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"m1r14\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gusta que te tiren del pelo mientras tienes sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\" style=\"background-color: #E3D3D5;\">\n      <ion-col >\n        <label for=\"m1l1\">SI</label>\n        <input id=\"m1l1\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"m1l2\">NO  </label>\n        <input id=\"m1l2\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n\n\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Te gusta que te exciten con palabras? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m1l6\">SI</label>\n        <input id=\"m1l6\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"m1l7\">NO  </label>\n        <input id=\"m1l7\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que es lo mas importante para ti en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n      </ion-col>\n\n      <ion-col>\n\n        <ion-input class=\"iput\"></ion-input>\n\n      </ion-col>\n      <ion-col>\n        <img src=\"../../assets/pluse.svg\" alt=\"\">\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row12\"   >\n      <ion-label  >Que cosas no te gustan en el sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row13\">\n      <ion-col>\n\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n\n  </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_m-level1_m-level1_module_ts.js.map