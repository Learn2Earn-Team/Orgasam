(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_c-levellast_c-levellast_module_ts"],{

/***/ 3926:
/*!***********************************************************!*\
  !*** ./src/app/c-levellast/c-levellast-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevellastPageRoutingModule": () => (/* binding */ CLevellastPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _c_levellast_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-levellast.page */ 2253);




const routes = [
    {
        path: '',
        component: _c_levellast_page__WEBPACK_IMPORTED_MODULE_0__.CLevellastPage
    }
];
let CLevellastPageRoutingModule = class CLevellastPageRoutingModule {
};
CLevellastPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CLevellastPageRoutingModule);



/***/ }),

/***/ 1597:
/*!***************************************************!*\
  !*** ./src/app/c-levellast/c-levellast.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevellastPageModule": () => (/* binding */ CLevellastPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _c_levellast_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-levellast-routing.module */ 3926);
/* harmony import */ var _c_levellast_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-levellast.page */ 2253);







let CLevellastPageModule = class CLevellastPageModule {
};
CLevellastPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c_levellast_routing_module__WEBPACK_IMPORTED_MODULE_0__.CLevellastPageRoutingModule
        ],
        declarations: [_c_levellast_page__WEBPACK_IMPORTED_MODULE_1__.CLevellastPage]
    })
], CLevellastPageModule);



/***/ }),

/***/ 2253:
/*!*************************************************!*\
  !*** ./src/app/c-levellast/c-levellast.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevellastPage": () => (/* binding */ CLevellastPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_c_levellast_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./c-levellast.page.html */ 7227);
/* harmony import */ var _c_levellast_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-levellast.page.scss */ 5641);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let CLevellastPage = class CLevellastPage {
    constructor() { }
    ngOnInit() {
    }
};
CLevellastPage.ctorParameters = () => [];
CLevellastPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-c-levellast',
        template: _raw_loader_c_levellast_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_c_levellast_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CLevellastPage);



/***/ }),

/***/ 5641:
/*!***************************************************!*\
  !*** ./src/app/c-levellast/c-levellast.page.scss ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  height: 100%;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  text-align: center;\n  font-size: 22px;\n  color: white;\n  font-family: Montserrat-SemiBold;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list1 {\n  margin-top: 10px;\n  margin: 10px;\n  background: url('end screen.png') no-repeat center center/cover;\n  height: 65%;\n  border-radius: 20px;\n  font-size: 22px;\n  color: white;\n  font-family: Montserrat-SemiBold;\n}\n\n.list1 .row1 {\n  text-align: center;\n  color: #000;\n  justify-content: center;\n  align-items: center;\n  margin-top: 50px;\n}\n\n.list1 .row2 {\n  text-align: center;\n  justify-content: center;\n  align-items: center;\n  margin-top: 10px;\n}\n\n.img {\n  position: absolute;\n  bottom: 0rem;\n  left: 1rem;\n}\n\n.img2 {\n  position: absolute;\n  bottom: 0rem;\n  left: 4rem;\n}\n\n.img1 {\n  position: absolute;\n  bottom: 0rem;\n  right: 0.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImMtbGV2ZWxsYXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0VBQ0YsWUFBQTtBQUFGOztBQUdFO0VBQ0Usb0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQ047O0FBRUU7RUFDQyxnQkFBQTtFQUNDLFlBQUE7RUFDQSwrREFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsZ0NBQUE7QUFDSjs7QUFDSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUNOOztBQUVJO0VBQ0Usa0JBQUE7RUFDRSx1QkFBQTtFQUNDLG1CQUFBO0VBQ0EsZ0JBQUE7QUFBVDs7QUFJRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUFESjs7QUFJTTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUFEUjs7QUFJRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFESiIsImZpbGUiOiJjLWxldmVsbGFzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuICBoZWlnaHQ6IDEwMCU7XHJcblxyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9oZWFkZXJcXCBza3kucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiMzNkQzRTE7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5saXN0MXtcclxuICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIGJhY2tncm91bmQ6IHVybCgnLi4vLi4vYXNzZXRzL2VuZFxcIHNjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG4gICAgaGVpZ2h0OiA2NSU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcblxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICBjb2xvcjogIzAwMDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IDUwcHg7XHJcblxyXG4gICAgfVxyXG4gICAgLnJvdzJ7XHJcbiAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgfVxyXG5cclxuICB9XHJcbiAgLmltZyB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDByZW07XHJcbiAgICBsZWZ0OiAxcmVtO1xyXG5cclxuICAgICAgfVxyXG4gICAgICAuaW1nMiB7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGJvdHRvbTogMHJlbTtcclxuICAgICAgICBsZWZ0OiA0cmVtO1xyXG5cclxuICAgICAgICAgIH1cclxuICAuaW1nMXtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMHJlbTtcclxuICAgIHJpZ2h0OiAgMC41cmVtO1xyXG4gIH1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 7227:
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/c-levellast/c-levellast.page.html ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logoblue.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n  <ion-list class=\"list\">\n <ion-row class=\"row\" >\n      <ion-label>RESULTADOS</ion-label>\n    </ion-row>\n</ion-list>\n<ion-list class=\"list1\">\n\n  <ion-row class=\"row1\" >\n    <ion-label>Te Invitamos a disfrutar con tu pareja... estos son los resultados...</ion-label>\n  </ion-row>\n  <ion-row class=\"row2\" style=\"margin-top: 30px;\" >\n    <ion-label>a. clitoriana</ion-label>\n  </ion-row>\n  <ion-row class=\"row2\" >\n    <ion-label>a. clitoriana </ion-label>\n  </ion-row>\n  <ion-row class=\"row2\" >\n    <ion-label> a. clitoriana</ion-label>\n  </ion-row>\n  <img   class=\"img1\" src=\"../../assets/play.svg\" alt=\"\">\n  <img class=\"img2\"  src=\"../../assets/clastf.svg\" alt=\"\">\n</ion-list>\n\n<img class=\"img\"  src=\"../../assets/clastm.svg\" alt=\"\">\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_c-levellast_c-levellast_module_ts.js.map