(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_mprofilelecel_mprofilelecel_module_ts"],{

/***/ 5495:
/*!***************************************************************!*\
  !*** ./src/app/mprofilelecel/mprofilelecel-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MprofilelecelPageRoutingModule": () => (/* binding */ MprofilelecelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _mprofilelecel_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mprofilelecel.page */ 8346);




const routes = [
    {
        path: '',
        component: _mprofilelecel_page__WEBPACK_IMPORTED_MODULE_0__.MprofilelecelPage
    }
];
let MprofilelecelPageRoutingModule = class MprofilelecelPageRoutingModule {
};
MprofilelecelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MprofilelecelPageRoutingModule);



/***/ }),

/***/ 9103:
/*!*******************************************************!*\
  !*** ./src/app/mprofilelecel/mprofilelecel.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MprofilelecelPageModule": () => (/* binding */ MprofilelecelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _mprofilelecel_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mprofilelecel-routing.module */ 5495);
/* harmony import */ var _mprofilelecel_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mprofilelecel.page */ 8346);







let MprofilelecelPageModule = class MprofilelecelPageModule {
};
MprofilelecelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _mprofilelecel_routing_module__WEBPACK_IMPORTED_MODULE_0__.MprofilelecelPageRoutingModule
        ],
        declarations: [_mprofilelecel_page__WEBPACK_IMPORTED_MODULE_1__.MprofilelecelPage]
    })
], MprofilelecelPageModule);



/***/ }),

/***/ 8346:
/*!*****************************************************!*\
  !*** ./src/app/mprofilelecel/mprofilelecel.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MprofilelecelPage": () => (/* binding */ MprofilelecelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_mprofilelecel_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./mprofilelecel.page.html */ 6084);
/* harmony import */ var _mprofilelecel_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mprofilelecel.page.scss */ 3130);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let MprofilelecelPage = class MprofilelecelPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['m-level']);
    }
    goto1() {
        this.router.navigate(['m-level1']);
    }
    goto3() {
        this.router.navigate(['m-level2']);
    }
    goto4() {
        this.router.navigate(['m-level3']);
    }
    goto5() {
        this.router.navigate(['blackcastle']);
    }
    gotosearch() {
        this.router.navigate(['searchprofile']);
    }
};
MprofilelecelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
MprofilelecelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-mprofilelecel',
        template: _raw_loader_mprofilelecel_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_mprofilelecel_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MprofilelecelPage);



/***/ }),

/***/ 3130:
/*!*******************************************************!*\
  !*** ./src/app/mprofilelecel/mprofilelecel.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #57BAF3;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list1 {\n  background: transparent;\n  height: 165px;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n  color: #2275A3;\n}\n\n.list1 .row1 {\n  justify-content: center;\n}\n\n.list1 .avatar3 {\n  height: 100px;\n  width: 100px;\n  margin-top: 10px;\n}\n\n.list1 .row2 {\n  justify-content: center;\n}\n\n.list3 {\n  background: #75C3EF;\n  padding: 9px;\n  margin-top: 10px;\n}\n\n.list3 .row1 {\n  justify-content: center;\n}\n\n.list3 .row1 .input1 {\n  margin-left: 5px;\n  width: 270px;\n  border-radius: 17px;\n  height: 32px;\n  border-color: transparent;\n}\n\n.list4 {\n  background: #fff url('manlevel.png') no-repeat center center/cover;\n  height: 400px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1wcm9maWxlbGVjZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsbUJBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBR0U7RUFDSSx1QkFBQTtFQUNBLGFBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBQU47O0FBQ007RUFDSSx1QkFBQTtBQUNWOztBQUNNO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUNWOztBQUNNO0VBQ0UsdUJBQUE7QUFDUjs7QUFFRTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQUk7RUFDSSx1QkFBQTtBQUVSOztBQURRO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFHWjs7QUFDQTtFQUNJLGtFQUFBO0VBQ0EsYUFBQTtBQUVKIiwiZmlsZSI6Im1wcm9maWxlbGVjZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNTdCQUYzO1xyXG5cclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG5cclxuICAubGlzdDF7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBoZWlnaHQ6IDE2NXB4O1xyXG4gICAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBjb2xvcjogIzIyNzVBMztcclxuICAgICAgLnJvdzF7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgfVxyXG4gICAgICAuYXZhdGFyM3tcclxuICAgICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5yb3cye1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICB9XHJcbiAgfVxyXG4gIC5saXN0M3tcclxuICAgIGJhY2tncm91bmQ6ICM3NUMzRUY7XHJcbiAgICBwYWRkaW5nOiA5cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgLnJvdzF7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgLmlucHV0MXtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICAgICAgICAgICAgd2lkdGg6IDI3MHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxN3B4O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbi5saXN0NHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLy4uLy4uL2Fzc2V0cy9sZXZlbC9tYW5sZXZlbC5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG4gICAgaGVpZ2h0OiA0MDBweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 6084:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mprofilelecel/mprofilelecel.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n    <!-- <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\"> -->\n  </ion-header>\n  <ion-list class=\"list1\">\n    <ion-row class=\"row1\">\n      <ion-avatar class=\"avatar3\">\n        <img  src=\"assets/person.png\">\n      </ion-avatar>\n      <img src=\"../../assets/editblue.svg\" style=\"margin-top: -55px;\">\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-label style=\"color: #2D3032;\">\n        SARA RODRÍGUEZ SOTO\n      </ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-label>\n        SOLTERA / HETEROSEXUAL\n      </ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      31 AÑOS\n    </ion-row>\n  </ion-list>\n  <ion-list class=\"list3\">\n    <ion-row class=\"row1\">\n      <img class=\"logo1\" src=\"./../../assets/search.svg\">\n      <input type=\"text\" class=\"input1\" />\n    </ion-row>\n\n  </ion-list>\n\n  <ion-list class=\"list4\">\n    <img src=\"./assets/level/fstart.svg\" style=\"position: absolute;\" (click)=\"goto()\">\n    <img src=\"./assets/level/flevel2.svg\" style=\"    position: absolute;\n  top: 30%;\n    right: 33%;\" (click)=\"goto1()\">\n    <img src=\"./assets/level/flevel3.svg\" style=\"position: absolute;\n    /* left: 37px; */\n    top: 33px;\n    right: 0px;\" (click)=\"goto3()\">\n    <img src=\"./assets/level/fend.svg\" style=\"\n        position: absolute;\n        bottom: -31px;\n        left: -41px;\" (click)=\"goto4()\">\n    <img src=\"./assets/level/mblackcastel.svg \" style=\"position: absolute; bottom: 0px; right: -38px;\" (click)=\"goto5()\">\n  </ion-list>\n\n  </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_mprofilelecel_mprofilelecel_module_ts.js.map