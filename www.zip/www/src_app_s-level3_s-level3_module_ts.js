(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_s-level3_s-level3_module_ts"],{

/***/ 3576:
/*!*****************************************************!*\
  !*** ./src/app/s-level3/s-level3-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel3PageRoutingModule": () => (/* binding */ SLevel3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_level3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level3.page */ 4841);




const routes = [
    {
        path: '',
        component: _s_level3_page__WEBPACK_IMPORTED_MODULE_0__.SLevel3Page
    }
];
let SLevel3PageRoutingModule = class SLevel3PageRoutingModule {
};
SLevel3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SLevel3PageRoutingModule);



/***/ }),

/***/ 9425:
/*!*********************************************!*\
  !*** ./src/app/s-level3/s-level3.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel3PageModule": () => (/* binding */ SLevel3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level3-routing.module */ 3576);
/* harmony import */ var _s_level3_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level3.page */ 4841);







let SLevel3PageModule = class SLevel3PageModule {
};
SLevel3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__.SLevel3PageRoutingModule
        ],
        declarations: [_s_level3_page__WEBPACK_IMPORTED_MODULE_1__.SLevel3Page]
    })
], SLevel3PageModule);



/***/ }),

/***/ 4841:
/*!*******************************************!*\
  !*** ./src/app/s-level3/s-level3.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel3Page": () => (/* binding */ SLevel3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_level3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-level3.page.html */ 7090);
/* harmony import */ var _s_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level3.page.scss */ 8878);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let SLevel3Page = class SLevel3Page {
    constructor(router, alert) {
        this.router = router;
        this.alert = alert;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['c-level']);
    }
};
SLevel3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
SLevel3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-s-level3',
        template: _raw_loader_s_level3_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SLevel3Page);



/***/ }),

/***/ 8878:
/*!*********************************************!*\
  !*** ./src/app/s-level3/s-level3.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  font-family: Montserrat-SemiBold;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.row16 {\n  padding: 5px;\n  text-align: center;\n  justify-content: center;\n  font-family: Montserrat-SemiBold;\n}\n\n.row17 {\n  padding: 5px;\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n  font-family: Montserrat-SemiBold;\n}\n\n.row21 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row22 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtbGV2ZWwzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNJLGdDQUFBO0VBQ0YsdUJBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQU47O0FBRUk7RUFDRSxrQkFBQTtFQUNBLHVCQUFBO0FBQU47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsZ0JBQUE7QUFITjs7QUFLSTtFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUFKTjs7QUFVRTtFQUNFLGFBQUE7QUFQSjs7QUFTRTtFQUNFLFdBQUE7RUFDQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBTko7O0FBUUU7RUFDRSx5QkFBQTtBQUxKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFMSjs7QUFRRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBTEo7O0FBUUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUxKOztBQVFFO0VBQ0UsZUFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7QUFOSjs7QUFTRTtFQUVFLGtCQUFBO0VBQ0EsdUJBQUE7RUFFQSxnQkFBQTtBQVJKOztBQVdFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDRixxQkFBQTtBQVJGOztBQVlFO0VBQ0MsZ0JBQUE7RUFFQyx1QkFBQTtBQVZKOztBQWFFO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtBQVZKOztBQVlJO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FBVE47O0FBV0U7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdDQUFBO0FBVEo7O0FBV0U7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0VBQ0EsZ0NBQUE7QUFUSjs7QUFhRTtFQUNFLGVBQUE7RUFFQSxrQkFBQTtFQUNBLHVCQUFBO0FBWEo7O0FBY0U7RUFFSSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsZ0JBQUE7QUFiTiIsImZpbGUiOiJzLWxldmVsMy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcblxyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9oZWFkZXJcXCBza3kucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjMzZEM0UxO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MXtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICB9XHJcbiAgICAucm93MntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4gICAgLmxhYmx7XHJcblxyXG4gICAgICBtYXJnaW4tbGVmdDogMy41cHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogMy41cHg7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXJnaW46IDAgMC41ZW07XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbiAgfVxyXG5cclxuICAucmFkaW8xICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucm93M3tcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxuXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3c0e1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuICAuYnRuIHtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICB9XHJcbiAgLnJvdzh7XHJcbiAgIG1hcmdpbi10b3A6IDE1cHg7XHJcblxyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAudGV4dDF7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1MHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWlucHV0IHtcclxuICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOnJnYigyNTUsIDI1NSwgMjU1KVxyXG4gICAgfVxyXG4gIC5yb3cxNntcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIH1cclxuICAucm93MTd7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcblxyXG4gIH1cclxuXHJcbiAgLnJvdzIxe1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzIye1xyXG5cclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiJdfQ== */");

/***/ }),

/***/ 7090:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-level3/s-level3.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-buttons  slot=\"end\" style = \"margin-top: -18px;\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logoblue.svg\" alt=\"\">\n      </ion-list>\n      <img style=\"position: absolute;bottom: -10px; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\" (click)=\"profile()\">\n\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/gmlevel3.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row16\" style=\" background: #BEDDE0;\" >\n      <ion-label  >¿Te disfrazarías como fantasía sexual?  </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\" style=\" background: #BEDDE0;\" >\n      <ion-col>\n        <label for=\"s3r1\">SI</label>\n        <input id=\"s3r1\" type=\"radio\" name=\"group51\" class=\"radio1\" />\n        <label for=\"s3r2\">NO</label>\n        <input id=\"s3r2\" type=\"radio\" name=\"group51\" class=\"radio2\" />\n        <label for=\"s3r3\">NO LO SÉ</label>\n        <input id=\"s3r3\" type=\"radio\" name=\"group51\" class=\"radio3\" />\n        <label for=\"s3r3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row16\" >\n      <ion-label  >¿Tienes algún fetiche? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <label for=\"s3a1\">SI</label>\n        <input id=\"s3a1\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"s3a2\">NO</label>\n        <input id=\"s3a2\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"s3a3\">NO LO SÉ</label>\n        <input id=\"s3a3\" type=\"radio\" name=\"group7\" class=\"radio3\" />\n        <label for=\"s3a3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row16\" style=\" background: #BEDDE0;\"  >\n      <ion-label  >¿Estarías dispuesta a hacer un trio?  </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\"  >\n      <ion-col >\n        <label for=\"s3l1\">SI</label>\n        <input id=\"s3l1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"s3l2\">NO</label>\n        <input id=\"s3l2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"s3l3\">NO LO SÉ</label>\n        <input id=\"s3l3\" type=\"radio\" name=\"group2\" class=\"radio3\" />\n        <label for=\"s3l3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row16\" >\n      <ion-label  >¿Tienes fantasias con otras personas que no sean tu pareja? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <label for=\"s3q1\">SI</label>\n        <input id=\"s3q1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"s3q2\">NO</label>\n        <input id=\"s3q2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"s3q3\">NO LO SÉ</label>\n        <input id=\"s3q3\" type=\"radio\" name=\"group3\" class=\"radio3\" />\n        <label for=\"s3q3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row16\" style=\" background: #BEDDE0;\"  >\n      <ion-label  >¿Has probado el cibersexo?  </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\" style=\" background: #BEDDE0;\" >\n      <ion-col >\n        <label for=\"s3w1\">SI</label>\n        <input id=\"s3w1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"s3w2\">NO</label>\n        <input id=\"s3w2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"s3w3\">NO LO SÉ</label>\n        <input id=\"s3w3\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"s3w3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row16\"  >\n      <ion-label  >Que cosas te gustarían hacer y nunca has hecho?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\"  >\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"  style=\" background: #BEDDE0;\"  >\n      <ion-label  >Cuales son las posturas que mas te gustan?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\" style=\" background: #BEDDE0;\"  >\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click) = \"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n  </ion-list>\n\n\n\n\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_s-level3_s-level3_module_ts.js.map