(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_tutorial2_tutorial2_module_ts"],{

/***/ 1376:
/*!*******************************************************!*\
  !*** ./src/app/tutorial2/tutorial2-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tutorial2PageRoutingModule": () => (/* binding */ Tutorial2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _tutorial2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tutorial2.page */ 8060);




const routes = [
    {
        path: '',
        component: _tutorial2_page__WEBPACK_IMPORTED_MODULE_0__.Tutorial2Page
    }
];
let Tutorial2PageRoutingModule = class Tutorial2PageRoutingModule {
};
Tutorial2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Tutorial2PageRoutingModule);



/***/ }),

/***/ 1140:
/*!***********************************************!*\
  !*** ./src/app/tutorial2/tutorial2.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tutorial2PageModule": () => (/* binding */ Tutorial2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _tutorial2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tutorial2-routing.module */ 1376);
/* harmony import */ var _tutorial2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tutorial2.page */ 8060);







let Tutorial2PageModule = class Tutorial2PageModule {
};
Tutorial2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _tutorial2_routing_module__WEBPACK_IMPORTED_MODULE_0__.Tutorial2PageRoutingModule
        ],
        declarations: [_tutorial2_page__WEBPACK_IMPORTED_MODULE_1__.Tutorial2Page]
    })
], Tutorial2PageModule);



/***/ }),

/***/ 8060:
/*!*********************************************!*\
  !*** ./src/app/tutorial2/tutorial2.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tutorial2Page": () => (/* binding */ Tutorial2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_tutorial2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tutorial2.page.html */ 2828);
/* harmony import */ var _tutorial2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tutorial2.page.scss */ 6944);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let Tutorial2Page = class Tutorial2Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['ligin1']);
    }
};
Tutorial2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Tutorial2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tutorial2',
        template: _raw_loader_tutorial2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tutorial2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Tutorial2Page);



/***/ }),

/***/ 6944:
/*!***********************************************!*\
  !*** ./src/app/tutorial2/tutorial2.page.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: #fff url('test.png') no-repeat center center / cover;\n}\n\nion-header {\n  --ion-background-color: #DB4066;\n}\n\nion-toolbar {\n  --background: #DB4066;\n  height: 89px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-list {\n  background: transparent;\n  color: white;\n  text-align: center;\n  font-family: Montserrat-SemiBold;\n  height: 414px;\n}\n\n.list_lock {\n  background: #F2C9D0;\n  margin-top: 25px;\n  height: 140px;\n  font-family: Montserrat;\n  line-height: 15px;\n}\n\n.line1 {\n  background-color: #D0355B;\n  width: 95%;\n  margin-top: 0px;\n}\n\n.lock_row1 {\n  font-weight: bold;\n  font-size: 15px;\n  margin-top: 10px;\n}\n\n.lock_col1 {\n  color: #D0355B;\n  font-size: 20px;\n}\n\n.lock_col2 {\n  color: black;\n  font-size: 12px;\n  font-family: Montserrat-Regular;\n}\n\n.avatar3 {\n  height: 66px;\n  width: 66px;\n  margin-top: -5px;\n  margin-left: 5px;\n}\n\n.list2_row1 {\n  margin-left: 5px;\n  font-size: 20px;\n  font-family: Montserrat-Bold;\n}\n\n.list2_col2 {\n  color: #D0355B;\n  font-size: 20px;\n}\n\n.avatar4 {\n  height: 66px;\n  width: 66px;\n  margin-left: -8px;\n}\n\n.list2_row3 {\n  margin-top: -20px;\n  font-size: 12px;\n  font-family: Montserrat-Regular;\n}\n\n.line2 {\n  background-color: #E1B9BF;\n  width: 95%;\n}\n\n.list2_col3 {\n  color: #D0355B;\n  font-size: 20px;\n  margin: 0px;\n  padding: 0px;\n}\n\n.list2-label {\n  text-align: left;\n  margin-left: 14%;\n  font-size: 33px;\n  font-weight: bold;\n}\n\n.btn {\n  background: #E4DB69;\n  margin-left: 12%;\n  margin-right: 38%;\n  padding: 10px;\n  border-radius: 27px;\n  color: #80464F;\n  font-size: 20px;\n  font-family: Montserrat-Bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR1dG9yaWFsMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFRSxrRUFBQTtBQUFGOztBQUVBO0VBQ0UsK0JBQUE7QUFDRjs7QUFDQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0EsZ0NBQUE7QUFFRjs7QUFDQTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxhQUFBO0FBRUY7O0FBQUE7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUVBLHVCQUFBO0VBQ0EsaUJBQUE7QUFFRjs7QUFBQTtFQUNFLHlCQUNFO0VBQ0YsVUFBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBR0Y7O0FBREE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQUlGOztBQUZBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSwrQkFBQTtBQUtGOztBQUhBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FBTUY7O0FBSEE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtBQU1GOztBQUpBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFPRjs7QUFMQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUFRRjs7QUFMQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLCtCQUFBO0FBUUY7O0FBTkE7RUFDRSx5QkFBQTtFQUNBLFVBQUE7QUFTRjs7QUFQQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFVRjs7QUFSQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFXRjs7QUFUQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7QUFZRiIsImZpbGUiOiJ0dXRvcmlhbDIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi4vLi4vYXNzZXRzL3Rlc3QucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxufVxyXG5pb24taGVhZGVye1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6ICNEQjQwNjY7XHJcbn1cclxuaW9uLXRvb2xiYXJ7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjREI0MDY2O1xyXG4gIGhlaWdodDogODlweDtcclxuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG59XHJcblxyXG5pb24tbGlzdHtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIGhlaWdodDogNDE0cHg7XHJcbn1cclxuLmxpc3RfbG9ja3tcclxuICBiYWNrZ3JvdW5kOiAjRjJDOUQwO1xyXG4gIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgaGVpZ2h0OiAxNDBweDtcclxuXHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQ7XHJcbiAgbGluZS1oZWlnaHQ6IDE1cHg7XHJcbn1cclxuLmxpbmUxe1xyXG4gIGJhY2tncm91bmQtY29sb3I6XHJcbiAgICAjRDAzNTVCO1xyXG4gIHdpZHRoOiA5NSU7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG59XHJcbi5sb2NrX3JvdzF7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG4gIG1hcmdpbi10b3A6IDEwcHhcclxufVxyXG4ubG9ja19jb2wxe1xyXG4gIGNvbG9yOiNEMDM1NUI7XHJcbiAgZm9udC1zaXplOiAyMHB4XHJcbn1cclxuLmxvY2tfY29sMntcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVJlZ3VsYXI7XHJcbn1cclxuLmF2YXRhcjN7XHJcbiAgaGVpZ2h0OiA2NnB4O1xyXG4gIHdpZHRoOiA2NnB4O1xyXG4gIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDVweDtcclxufVxyXG5cclxuLmxpc3QyX3JvdzF7XHJcbiAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtQm9sZDtcclxufVxyXG4ubGlzdDJfY29sMntcclxuICBjb2xvcjojRDAzNTVCO1xyXG4gIGZvbnQtc2l6ZTogMjBweFxyXG59XHJcbi5hdmF0YXI0e1xyXG4gIGhlaWdodDogNjZweDtcclxuICB3aWR0aDogNjZweDtcclxuICBtYXJnaW4tbGVmdDogLThweDtcclxuXHJcbn1cclxuLmxpc3QyX3JvdzN7XHJcbiAgbWFyZ2luLXRvcDogLTIwcHg7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVJlZ3VsYXI7XHJcbn1cclxuLmxpbmUye1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNFMUI5QkY7XHJcbiAgd2lkdGg6IDk1JTtcclxufVxyXG4ubGlzdDJfY29sM3tcclxuICBjb2xvcjojRDAzNTVCO1xyXG4gIGZvbnQtc2l6ZTogMjBweCA7XHJcbiAgbWFyZ2luOiAwcHg7XHJcbiAgcGFkZGluZzogMHB4XHJcbn1cclxuLmxpc3QyLWxhYmVse1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDE0JTtcclxuICBmb250LXNpemU6IDMzcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLmJ0bntcclxuICBiYWNrZ3JvdW5kOiAjRTREQjY5O1xyXG4gIG1hcmdpbi1sZWZ0OiAxMiU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAzOCU7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiAyN3B4O1xyXG4gIGNvbG9yOiAjODA0NjRGO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBmb250LWZhbWlseTogTW9udHNlcnJhdC1Cb2xkO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 2828:
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tutorial2/tutorial2.page.html ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" (click) =\"goto()\">\n<div>\n  <ion-list  class=\"list_lock\">\n    <ion-grid >\n      <ion-row class =\"lock_row1\">\n        <ion-col size=\"7\" >\n          <hr class=\"line1\" >\n        </ion-col>\n        <ion-col size=\"5\" style = \"color:#D0355B; font-size: 20px ;margin: 0px;padding: 0px\">\n          Black Casttle\n        </ion-col>\n      </ion-row>\n      <ion-row class = \"lock_col1\">\n        <ion-col size=\"2.5\">\n          <ion-avatar class= \"avatar3\">\n            <img  src=\"assets/5th.svg\">\n          </ion-avatar>\n        </ion-col >\n        <ion-col class = \"lock_col2\" size=\"9\">\n          Este mundo recoge las preguntas mas picantes, las más secretas, acceder a esta información de tu pareja tiene un costo adicional y sólo podrá ser generado el pago si la persona accede a dejarte entrar a lo mas oscuro de su sexualidad!\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-list>\n\n  <ion-list>\n    <ion-grid >\n      <ion-row class=\"list2_row1\">\n        <ion-col size=\"7\" >\n          Recorre el Camino\n        </ion-col>\n        <ion-col clas = \"list2_col2\" size=\"3\">\n          <hr class=\"line2\" >\n        </ion-col>\n        <ion-col size=\"2\" class =\"list2_col3\">\n          <ion-avatar class =\"avatar4\">\n            <img  src=\"assets/4th.svg\">\n          </ion-avatar>\n        </ion-col>\n      </ion-row>\n      <ion-row  class= \"list2_row3 \">\n        <ion-col size=\"9\">\n          Una vez hayas recorrido el mapa de tu pareja, la aplicación te arrojara una información sobre cómo generarle ese punto máximo de placer para llevarla hasta el clímax!\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    <p class = \"list2-label\">\n      AHORA, SÍ VEMONOS!\n    </p>\n    <p class=\"btn\">\n      HAGAMOSLO!\n    </p>\n    <img src=\"../../assets/togerther.svg\" style=\"    position: absolute;\n    bottom: -34px;\n    right: -37px;\">\n  </ion-list>\n\n</div>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_tutorial2_tutorial2_module_ts.js.map