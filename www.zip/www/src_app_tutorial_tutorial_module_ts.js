(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_tutorial_tutorial_module_ts"],{

/***/ 5922:
/*!*****************************************************!*\
  !*** ./src/app/tutorial/tutorial-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TutorialPageRoutingModule": () => (/* binding */ TutorialPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _tutorial_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tutorial.page */ 1579);




const routes = [
    {
        path: '',
        component: _tutorial_page__WEBPACK_IMPORTED_MODULE_0__.TutorialPage
    }
];
let TutorialPageRoutingModule = class TutorialPageRoutingModule {
};
TutorialPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TutorialPageRoutingModule);



/***/ }),

/***/ 1494:
/*!*********************************************!*\
  !*** ./src/app/tutorial/tutorial.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TutorialPageModule": () => (/* binding */ TutorialPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _tutorial_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tutorial-routing.module */ 5922);
/* harmony import */ var _tutorial_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tutorial.page */ 1579);







let TutorialPageModule = class TutorialPageModule {
};
TutorialPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _tutorial_routing_module__WEBPACK_IMPORTED_MODULE_0__.TutorialPageRoutingModule
        ],
        declarations: [_tutorial_page__WEBPACK_IMPORTED_MODULE_1__.TutorialPage]
    })
], TutorialPageModule);



/***/ }),

/***/ 1579:
/*!*******************************************!*\
  !*** ./src/app/tutorial/tutorial.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TutorialPage": () => (/* binding */ TutorialPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_tutorial_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tutorial.page.html */ 2395);
/* harmony import */ var _tutorial_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tutorial.page.scss */ 8800);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let TutorialPage = class TutorialPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['tutorial2']);
    }
};
TutorialPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
TutorialPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tutorial',
        template: _raw_loader_tutorial_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tutorial_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TutorialPage);



/***/ }),

/***/ 8800:
/*!*********************************************!*\
  !*** ./src/app/tutorial/tutorial.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: #fff url('test.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header Pr.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: #DB4066;\n  height: 89px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list_lock {\n  background: #F2C9D0;\n  margin-top: 25px;\n  height: 211px;\n  font-family: Montserrat;\n  line-height: 15px;\n}\n\n.line1 {\n  background-color: #D0355B;\n  width: 95%;\n  margin-top: 0px;\n}\n\n.lock_row1 {\n  font-weight: bold;\n  font-size: 15px;\n  margin-top: 10px;\n}\n\n.lock_col1 {\n  color: #D0355B;\n  font-size: 20px;\n}\n\n.lock_col2 {\n  color: #070707;\n  font-size: 12px;\n  font-family: Montserrat-Regular;\n}\n\n.lock_col3 {\n  color: black;\n  font-size: 12px;\n  text-align: center;\n  font-family: Montserrat-SemiBold;\n}\n\n.list2_row1 {\n  margin-left: 5px;\n  font-size: 20px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list2_col2 {\n  color: #D0355B;\n  font-size: 20px;\n}\n\n.avatar3 {\n  height: 66px;\n  width: 66px;\n  margin-top: -5px;\n  margin-left: 5px;\n}\n\n.avatar4 {\n  height: 66px;\n  width: 66px;\n  margin-left: -8px;\n}\n\n.list2_row3 {\n  margin-top: -34px;\n  font-size: 12px;\n  font-family: Montserrat-Regular;\n}\n\n.line2 {\n  background-color: #E1B9BF;\n  width: 95%;\n}\n\n.list2_col3 {\n  color: #D0355B;\n  font-size: 20px;\n  margin: 0px;\n  padding: 0px;\n}\n\n.list3 {\n  border: 2px solid white;\n  margin-left: 5%;\n  margin-top: 10px;\n  margin-right: 5%;\n  border-radius: 50px;\n  height: 97px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list4_label1 {\n  font-size: 15px;\n  font-weight: bold;\n}\n\n.list4_label2 {\n  font-size: 15px;\n  font-weight: bold;\n  color: #FFA2BA;\n}\n\n.list4_label3 {\n  font-size: 10px;\n  font-weight: bold;\n  color: #E4E4E4;\n  background: #CA063A;\n  padding: 6px;\n  padding-right: 15px;\n  margin-right: 20px;\n  border-radius: 13px;\n}\n\n.list4_label4 {\n  font-size: 10px;\n  font-weight: bold;\n  color: #E4E4E4;\n  background: #CA063A;\n  padding: 6px;\n  padding-right: 15px;\n  border-radius: 13px;\n  justify-content: right;\n}\n\n.list5 {\n  height: 102px;\n  background-image: url('bba.png');\n  margin-top: 7px;\n}\n\n.list5_p1 {\n  font-size: 12px;\n  font-family: Montserrat-Regular;\n  color: black;\n}\n\n.row2 {\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n  margin-top: -5px;\n  color: black;\n  font-family: Montserrat-SemiBold;\n}\n\n.labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #F94272;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.input1 {\n  width: 82px;\n}\n\nion-list {\n  background: transparent;\n  color: white;\n  text-align: center;\n  font-family: Montserrat;\n}\n\np {\n  line-height: 20px;\n  /* text-align: center; */\n  margin-left: 34px;\n  margin-right: 35px;\n  justify-content: center;\n}\n\nh1 {\n  margin-right: 30px;\n  margin-left: 30px;\n  justify-content: center;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR1dG9yaWFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLGtFQUFBO0FBQUY7O0FBRUE7RUFDRSxtRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFBSDs7QUFFQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0EsZ0NBQUE7QUFDRjs7QUFDQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBRUEsdUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUNBO0VBQ0UseUJBQ0U7RUFDRixVQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFFRjs7QUFBQTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLCtCQUFBO0FBSUY7O0FBRkE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7QUFLRjs7QUFIQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdDQUFBO0FBTUY7O0FBSkE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQU9GOztBQUpBO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FBT0Y7O0FBTEE7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0FBUUY7O0FBTEE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSwrQkFBQTtBQVFGOztBQUxBO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0FBUUY7O0FBTkE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBU0Y7O0FBTkE7RUFDRSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0NBQUE7QUFTRjs7QUFQQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQVVGOztBQVJBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQVdGOztBQVRBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQVlGOztBQVZBO0VBQ0csZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0QsWUFBQTtFQUNBLG1CQUFBO0VBQ0MsbUJBQUE7RUFDRCxzQkFBQTtBQWFGOztBQVZBO0VBQ0UsYUFBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtBQWFGOztBQVhBO0VBRUUsZUFBQTtFQUNBLCtCQUFBO0VBQ0EsWUFBQTtBQWFGOztBQVhBO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtBQWFGOztBQVhBO0VBRUUsa0JBQUE7RUFDQSxtQkFBQTtBQWFGOztBQVBBO0VBQ0UsYUFBQTtBQVVGOztBQVJBO0VBQ0UsV0FBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFXRjs7QUFUQTtFQUNFLHlCQUFBO0FBWUY7O0FBVEE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQVlGOztBQVRBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFZRjs7QUFUQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBWUY7O0FBVkE7RUFDRSxXQUFBO0FBYUY7O0FBVEE7RUFDRSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBWUY7O0FBVkE7RUFDRSxpQkFBQTtFQUNBLHdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBYUY7O0FBWEE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQWNGIiwiZmlsZSI6InR1dG9yaWFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy90ZXN0LnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcbn1cclxuaW9uLWhlYWRlcntcclxuICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi8uLi8uLi9hc3NldHMvaGVhZGVyXFwgUHIucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuICBcclxuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxufVxyXG5pb24tdG9vbGJhcntcclxuICAtLWJhY2tncm91bmQ6ICNEQjQwNjY7XHJcbiAgaGVpZ2h0OiA4OXB4O1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbn1cclxuLmxpc3RfbG9ja3tcclxuICBiYWNrZ3JvdW5kOiAjRjJDOUQwO1xyXG4gIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgaGVpZ2h0OiAyMTFweDtcclxuXHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQ7XHJcbiAgbGluZS1oZWlnaHQ6IDE1cHg7XHJcbn1cclxuLmxpbmUxe1xyXG4gIGJhY2tncm91bmQtY29sb3I6XHJcbiAgICAjRDAzNTVCO1xyXG4gIHdpZHRoOiA5NSU7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG59XHJcbi5sb2NrX3JvdzF7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG4gIG1hcmdpbi10b3A6IDEwcHhcclxufVxyXG4ubG9ja19jb2wxe1xyXG4gIGNvbG9yOiNEMDM1NUI7XHJcbiAgZm9udC1zaXplOiAyMHB4XHJcbn1cclxuLmxvY2tfY29sMntcclxuICBjb2xvcjogIzA3MDcwNztcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtUmVndWxhcjtcclxufVxyXG4ubG9ja19jb2wze1xyXG4gIGNvbG9yOiBibGFjaztcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG59XHJcbi5saXN0Ml9yb3cxe1xyXG4gIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG59XHJcbi5saXN0Ml9jb2wye1xyXG4gIGNvbG9yOiNEMDM1NUI7XHJcbiAgZm9udC1zaXplOiAyMHB4XHJcbn1cclxuXHJcbi5hdmF0YXIze1xyXG4gIGhlaWdodDogNjZweDtcclxuICB3aWR0aDogNjZweDtcclxuICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbn1cclxuLmF2YXRhcjR7XHJcbiAgaGVpZ2h0OiA2NnB4O1xyXG4gIHdpZHRoOiA2NnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAtOHB4O1xyXG5cclxufVxyXG4ubGlzdDJfcm93M3tcclxuICBtYXJnaW4tdG9wOiAtMzRweDtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtUmVndWxhcjtcclxuXHJcbn1cclxuLmxpbmUye1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNFMUI5QkY7XHJcbiAgd2lkdGg6IDk1JTtcclxufVxyXG4ubGlzdDJfY29sM3tcclxuICBjb2xvcjojRDAzNTVCO1xyXG4gIGZvbnQtc2l6ZTogMjBweCA7XHJcbiAgbWFyZ2luOiAwcHg7XHJcbiAgcGFkZGluZzogMHB4XHJcbn1cclxuXHJcbi5saXN0M3tcclxuICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDUlIDtcclxuICBib3JkZXItcmFkaXVzOiA1MHB4IDtcclxuICBoZWlnaHQ6IDk3cHg7XHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbn1cclxuLmxpc3Q0X2xhYmVsMXtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLmxpc3Q0X2xhYmVsMntcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgY29sb3I6ICNGRkEyQkE7XHJcbn1cclxuLmxpc3Q0X2xhYmVsM3tcclxuICBmb250LXNpemU6IDEwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgY29sb3I6ICNFNEU0RTQ7XHJcbiAgYmFja2dyb3VuZDogI0NBMDYzQTtcclxuICBwYWRkaW5nOiA2cHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTVweDtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTNweDtcclxufVxyXG4ubGlzdDRfbGFiZWw0e1xyXG4gICBmb250LXNpemU6IDEwcHg7XHJcbiAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICBjb2xvcjogI0U0RTRFNDtcclxuICAgYmFja2dyb3VuZDogI0NBMDYzQTtcclxuICBwYWRkaW5nOiA2cHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTVweDtcclxuICAgYm9yZGVyLXJhZGl1czogMTNweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHJpZ2h0O1xyXG4gfVxyXG5cclxuLmxpc3Q1e1xyXG4gIGhlaWdodDogMTAycHg7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2JiYS5wbmdcIikgO1xyXG4gIG1hcmdpbi10b3A6IDdweDtcclxufVxyXG4ubGlzdDVfcDF7XHJcblxyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBmb250LWZhbWlseTogTW9udHNlcnJhdC1SZWd1bGFyO1xyXG4gIGNvbG9yOiBibGFjaztcclxufVxyXG4ucm93MntcclxuXHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gIGNvbG9yOiBibGFjaztcclxuICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxufVxyXG4ubGFibHtcclxuXHJcbiAgbWFyZ2luLWxlZnQ6IDMuNXB4O1xyXG4gIG1hcmdpbi1yaWdodDogMy41cHg7XHJcblxyXG59XHJcblxyXG5cclxuXHJcbmlucHV0W3R5cGU9cmFkaW9dIHtcclxuICBkaXNwbGF5OiBub25lO1xyXG59XHJcbmlucHV0W3R5cGU9cmFkaW9dICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgY29udGVudDogJyc7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIG1hcmdpbjogMCAwLjVlbTtcclxufVxyXG5pbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0Y5NDI3MjtcclxufVxyXG5cclxuLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gIHdpZHRoOiAwLjVlbTtcclxuICBoZWlnaHQ6IDAuNWVtO1xyXG59XHJcblxyXG4ucmFkaW8yICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgd2lkdGg6IDAuNWVtO1xyXG4gIGhlaWdodDogMC41ZW07XHJcbn1cclxuXHJcbi5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICB3aWR0aDogMC41ZW07XHJcbiAgaGVpZ2h0OiAwLjVlbTtcclxufVxyXG4uaW5wdXQxe1xyXG4gIHdpZHRoOiA4MnB4O1xyXG59XHJcblxyXG5cclxuaW9uLWxpc3R7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBmb250LWZhbWlseTogTW9udHNlcnJhdDtcclxufVxyXG5we1xyXG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gIC8qIHRleHQtYWxpZ246IGNlbnRlcjsgKi9cclxuICBtYXJnaW4tbGVmdDogMzRweDtcclxuICBtYXJnaW4tcmlnaHQ6IDM1cHg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuaDF7XHJcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 2395:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tutorial/tutorial.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" (click) =\"goto()\">\n<div>\n  <ion-list  class=\"list_lock\">\n    <ion-grid >\n      <ion-row class =\"lock_row1\">\n        <ion-col size=\"9\" >\n          <hr class=\"line1\" >\n        </ion-col>\n        <ion-col size=\"3\" style = \"color:#D0355B; font-size: 20px ;margin: 0px;padding: 0px ; font-family: Montserrat-SemiBold;\">\n          LOCK IT!\n        </ion-col>\n      </ion-row>\n      <ion-row class = \"lock_col1\">\n        <ion-col size=\"2.5\">\n          <ion-avatar class= \"avatar3\">\n            <img  src=\"assets/3rd.svg\">\n          </ion-avatar>\n        </ion-col >\n        <ion-col class = \"lock_col2\" size=\"9\">\n          Todo tiene su tiempo, podrás agregar una\n          a la pregunta que quieras reservar para mas adelante, Agregar una manzana en una pregunta, le exige a tu enamorad(@) pagar para saber un poco mas de ti!\n        </ion-col>\n        <ion-col class = \"lock_col3\" size=\"12\">\n          Te gusta desnudarte delante de tu pareja?\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"row2\">\n        <ion-col >\n          <label for=\"r1\">SI</label>\n          <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n          <label for=\"r2\">NO  </label>\n          <input id=\"r2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n          <label for=\"r3\">NO MUCHO</label>\n          <input id=\"r3\" type=\"radio\" name=\"group1\" class=\"radio3\" />\n          <label for=\"r3\"></label>\n        </ion-col>\n      </ion-row>\n      <ion-row style=\"background-color: #DCB1BD; margin-left: 0px; margin-right: 0px\">\n        <ion-col class = \"lock_col3\" size=\"12\">\n          ¿Sueles usar juguetes eróticos?\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"row2\" style=\"background-color: #DCB1BD\">\n        <ion-col >\n          <label for=\"l1\">SI</label>\n          <input id=\"l1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n          <label for=\"l2\">NO  </label>\n          <input id=\"l2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n          <label for=\"l3\">NO MUCHO</label>\n          <input id=\"l3\" type=\"text\" class=\"input1\" />\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </ion-list>\n\n  <ion-list>\n    <ion-grid >\n      <ion-row class=\"list2_row1\">\n        <ion-col size=\"7\" >\n          Busca a la persona\n        </ion-col>\n        <ion-col clas = \"list2_col2\" size=\"3\">\n          <hr class=\"line2\" >\n        </ion-col>\n        <ion-col size=\"2\" class =\"list2_col3\">\n          <ion-avatar class =\"avatar4\">\n            <img  src=\"assets/4th.svg\">\n          </ion-avatar>\n        </ion-col>\n      </ion-row>\n      <ion-row  class= \"list2_row3 \">\n        <ion-col size=\"9\">\n          Puedes buscar por su nombre, para acceder al mapa, sí el/ella te encontró primero, te llegara una invitación tu decides si hacen match y le permites entrar a tu mundo!        </ion-col >\n      </ion-row>\n    </ion-grid>\n  </ion-list>\n\n  <ion-list class=\"list3\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size =\"2\">\n          <ion-avatar class= \"avatar3\">\n            <img  src=\"assets/person.png\">\n          </ion-avatar>\n        </ion-col>\n        <ion-col siz = \"12\">\n          <ion-label class = \"list4_label1\">\n            SIMÓN LOPEZ SIERRA\n          </ion-label><br>\n          <ion-label class=\"list4_label2\">\n            SOLTERO\n          </ion-label\n          ><br>\n          <ion-label class=\"list4_label3\">\n            Aceptar Solicitud\n          </ion-label>\n          <ion-label class=\"list4_label4\">\n            Negar  Solicitud\n          </ion-label>\n\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </ion-list>\n\n  <ion-list class = \"list5\">\n    <p class=\"list5_p1\">\n      Una vez aceptada su solicitud, el podrá recorrer tu mapa, podrá acceder a las preguntas que quiera, o pagar por las que le has puesto difíciles de conseguir, igualmente tu podrás acceder al suyo\n    </p>\n\n  </ion-list>\n</div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_tutorial_tutorial_module_ts.js.map