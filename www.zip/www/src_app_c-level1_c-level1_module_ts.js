(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_c-level1_c-level1_module_ts"],{

/***/ 3660:
/*!*****************************************************!*\
  !*** ./src/app/c-level1/c-level1-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel1PageRoutingModule": () => (/* binding */ CLevel1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _c_level1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level1.page */ 5797);




const routes = [
    {
        path: '',
        component: _c_level1_page__WEBPACK_IMPORTED_MODULE_0__.CLevel1Page
    }
];
let CLevel1PageRoutingModule = class CLevel1PageRoutingModule {
};
CLevel1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CLevel1PageRoutingModule);



/***/ }),

/***/ 8421:
/*!*********************************************!*\
  !*** ./src/app/c-level1/c-level1.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel1PageModule": () => (/* binding */ CLevel1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _c_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level1-routing.module */ 3660);
/* harmony import */ var _c_level1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level1.page */ 5797);







let CLevel1PageModule = class CLevel1PageModule {
};
CLevel1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__.CLevel1PageRoutingModule
        ],
        declarations: [_c_level1_page__WEBPACK_IMPORTED_MODULE_1__.CLevel1Page]
    })
], CLevel1PageModule);



/***/ }),

/***/ 5797:
/*!*******************************************!*\
  !*** ./src/app/c-level1/c-level1.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel1Page": () => (/* binding */ CLevel1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_c_level1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./c-level1.page.html */ 7772);
/* harmony import */ var _c_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level1.page.scss */ 1876);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let CLevel1Page = class CLevel1Page {
    constructor(router, alert1) {
        this.router = router;
        this.alert1 = alert1;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['c-level2']);
    }
};
CLevel1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
CLevel1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-c-level1',
        template: _raw_loader_c_level1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_c_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CLevel1Page);



/***/ }),

/***/ 1876:
/*!*********************************************!*\
  !*** ./src/app/c-level1/c-level1.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pur.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  font-size: 15px;\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #7A3E6A;\n  height: 35px;\n  font-size: 22px;\n  color: white;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E3D3D5;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E3D3D5;\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  text-align: center;\n  justify-content: center;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.iput {\n  width: 70px;\n}\n\n.iput1 {\n  margin-right: 50px;\n}\n\n.row12 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row13 {\n  margin-top: -5px;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImMtbGV2ZWwxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGdDQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUVJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUFOOztBQUdJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBSE47O0FBS0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSk47O0FBVUU7RUFDRSxhQUFBO0FBUEo7O0FBU0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFFO0VBQ0UseUJBQUE7QUFMSjs7QUFRRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBTEo7O0FBUUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUxKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFMSjs7QUFRRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFMSjs7QUFRRTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBTE47O0FBUUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBTEY7O0FBU0U7RUFDQyxnQkFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7QUFQSDs7QUFVRTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQVBKOztBQVNFO0VBQ0UsV0FBQTtBQU5KOztBQVVFO0VBQ0Esa0JBQUE7QUFQRjs7QUFTRTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7QUFOSjs7QUFTRTtFQUdFLGdCQUFBO0FBUko7O0FBWUU7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBVEYiLCJmaWxlIjoiYy1sZXZlbDEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgcHVyLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG5cclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICM3QTNFNkE7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgfVxyXG4gICAgLnJvdzJ7XHJcblxyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgICAgbWFyZ2luLXRvcDogLTVweDtcclxuICAgIH1cclxuICAgIC5sYWJse1xyXG5cclxuICAgICAgbWFyZ2luLWxlZnQ6IDMuNXB4O1xyXG4gICAgICBtYXJnaW4tcmlnaHQ6IDMuNXB4O1xyXG5cclxuICAgIH1cclxuXHJcblxyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luOiAwIDAuNWVtO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjREMzNDYxO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzIgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8zICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJvdzN7XHJcbiAgICBtYXJnaW4tdG9wOiA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTNEM0Q1O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAucm93NHtcclxuICAgIGJhY2tncm91bmQ6ICNFM0QzRDU7XHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5idG4ge1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcblxyXG4gIH1cclxuICAucm93OHtcclxuICAgbWFyZ2luLXRvcDogMTVweDtcclxuXHJcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICBpb24taW5wdXQge1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZDpyZ2IoMjU1LCAyNTUsIDI1NSlcclxuICB9XHJcbiAgLmlwdXR7XHJcbiAgICB3aWR0aDogNzBweDtcclxuXHJcblxyXG4gIH1cclxuICAuaXB1dDF7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1MHB4O1xyXG4gIH1cclxuICAucm93MTJ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3cxM3tcclxuXHJcblxyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuXHJcbiAgfVxyXG5cclxuICAudGV4dDF7XHJcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUwcHg7XHJcbiAgfVxyXG5cclxuXHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ 7772:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/c-level1/c-level1.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logopr.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>JUGUEMOS JUNTOS</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/couple2.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >ALGUNA VEZ HAS TENIDO UN ORGASMO? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c1r1\">SI</label>\n        <input id=\"c1r1\" type=\"radio\" name=\"group441\" class=\"radio1\" />\n        <label for=\"c1r2\">NO</label>\n        <input id=\"c1r2\" type=\"radio\" name=\"group441\" class=\"radio2\" />\n        <label for=\"c1r3\">NO LO SÉ</label>\n        <input id=\"c1r3\" type=\"radio\" name=\"group441\" class=\"radio3\" />\n        <label for=\"c1r3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Te gusta que te acaricien el clítoris? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col  >\n        <label for=\"c1q1\">SI</label>\n        <input id=\"c1q1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"c1q2\">NO</label>\n        <input id=\"c1q2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"c1q2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Sueles usar juguetes eróticos? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c1l1\">SI</label>\n        <input id=\"c1l1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"c1l2\">NO  </label>\n        <input id=\"c1l2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"c1l3\">moch</label>\n        <input id=\"c1l3\" type=\"text\" style=\"width: 130px; margin-left: 10px;\" />\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Te gustan las esposas o mas juegos…</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"c1w1\">SI</label>\n        <input id=\"c1w1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"c1w2\">NO  </label>\n        <input id=\"c1w2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"c1w2\">moch</label>\n        <input id=\"c1w3\" type=\"text\" style=\"width: 130px; margin-left: 10px;\" />\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te consideras Vaginal o Clitórica? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c1e1\">Vaginal</label>\n        <input id=\"c1e1\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"c1e2\">Clitórica</label>\n        <input id=\"c1e2\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"c1e3\"> Ambas</label>\n        <input id=\"c1e3\" type=\"radio\" name=\"group5\" class=\"radio3\" />\n        <label for=\"c1e3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Te gusta que te hagan el culiningus?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"c1s1\">SI</label>\n        <input id=\"c1s1\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"c1s2\">NO</label>\n        <input id=\"c1s2\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"c1s2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Sientes placer al acariciarte el clítoris? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c1d1\">SI</label>\n        <input id=\"c1d1\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"c1d2\">NO</label>\n        <input id=\"c1d2\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"c1d2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Eres mas dominante o dominada? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"c1f1\">Dominante</label>\n        <input id=\"c1f1\" type=\"radio\" name=\"group8\" class=\"radio1\" />\n        <label for=\"c1f2\">Sumisa</label>\n        <input id=\"c1f2\" type=\"radio\" name=\"group8\" class=\"radio2\" />\n        <label for=\"c1f2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Eres una persona Romántica, sensual o pasional? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c1z1\">Romántica</label>\n        <input id=\"c1z1\" type=\"radio\" name=\"group9\" class=\"radio1\" />\n        <label for=\"c1z2\">Sensual</label>\n        <input id=\"c1z2\" type=\"radio\" name=\"group9\" class=\"radio2\" />\n        <label for=\"c1z3\">Pasional</label>\n        <input id=\"c1z3\" type=\"radio\" name=\"group9s\" class=\"radio3\" />\n        <label for=\"c1z3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\" >SIGUIENTE</ion-button>\n    </ion-row>\n    </ion-list>\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_c-level1_c-level1_module_ts.js.map