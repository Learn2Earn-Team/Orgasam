(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_c-level3_c-level3_module_ts"],{

/***/ 8141:
/*!*****************************************************!*\
  !*** ./src/app/c-level3/c-level3-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel3PageRoutingModule": () => (/* binding */ CLevel3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _c_level3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level3.page */ 8065);




const routes = [
    {
        path: '',
        component: _c_level3_page__WEBPACK_IMPORTED_MODULE_0__.CLevel3Page
    }
];
let CLevel3PageRoutingModule = class CLevel3PageRoutingModule {
};
CLevel3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CLevel3PageRoutingModule);



/***/ }),

/***/ 9451:
/*!*********************************************!*\
  !*** ./src/app/c-level3/c-level3.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel3PageModule": () => (/* binding */ CLevel3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _c_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level3-routing.module */ 8141);
/* harmony import */ var _c_level3_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level3.page */ 8065);







let CLevel3PageModule = class CLevel3PageModule {
};
CLevel3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__.CLevel3PageRoutingModule
        ],
        declarations: [_c_level3_page__WEBPACK_IMPORTED_MODULE_1__.CLevel3Page]
    })
], CLevel3PageModule);



/***/ }),

/***/ 8065:
/*!*******************************************!*\
  !*** ./src/app/c-level3/c-level3.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel3Page": () => (/* binding */ CLevel3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_c_level3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./c-level3.page.html */ 2488);
/* harmony import */ var _c_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level3.page.scss */ 9619);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let CLevel3Page = class CLevel3Page {
    constructor(router, alert1) {
        this.router = router;
        this.alert1 = alert1;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['c-levellast']);
    }
};
CLevel3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
CLevel3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-c-level3',
        template: _raw_loader_c_level3_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_c_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CLevel3Page);



/***/ }),

/***/ 9619:
/*!*********************************************!*\
  !*** ./src/app/c-level3/c-level3.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  font-size: 22px;\n  color: white;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.row16 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row17 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.row21 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row22 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImMtbGV2ZWwzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBQ0k7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUNJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUNOOztBQUNJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRk47O0FBUUU7RUFDRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UseUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFFQSxrQkFBQTtFQUNBLHVCQUFBO0FBSko7O0FBUUU7RUFFRSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsZ0JBQUE7QUFQSjs7QUFVRTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0YscUJBQUE7QUFQRjs7QUFXRTtFQUNDLGdCQUFBO0VBRUMsdUJBQUE7QUFUSjs7QUFZRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFUSjs7QUFXSTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQVJOOztBQVVFO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtBQVJKOztBQVdFO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBVko7O0FBY0U7RUFDRSxlQUFBO0VBRUEsa0JBQUE7RUFDQSx1QkFBQTtBQVpKOztBQWVFO0VBRUksa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBZE4iLCJmaWxlIjoiYy1sZXZlbDMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgc2t5LnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgLnJvd3tcclxuICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgYmFja2dyb3VuZDogIzM2RDNFMTtcclxuICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MXtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5yb3cye1xyXG5cclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiAgICAubGFibHtcclxuXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10gKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIG1hcmdpbjogMCAwLjVlbTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0RDMzQ2MTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzEgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8yICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMyArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yb3cze1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuXHJcbiAgfVxyXG4gIC5yb3c0e1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuICAuYnRuIHtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICB9XHJcbiAgLnJvdzh7XHJcbiAgIG1hcmdpbi10b3A6IDE1cHg7XHJcblxyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAudGV4dDF7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiA1MHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWlucHV0IHtcclxuICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOnJnYigyNTUsIDI1NSwgMjU1KVxyXG4gICAgfVxyXG4gIC5yb3cxNntcclxuXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3cxN3tcclxuXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG5cclxuICB9XHJcblxyXG4gIC5yb3cyMXtcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxuXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3cyMntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4iXX0= */");

/***/ }),

/***/ 2488:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/c-level3/c-level3.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logoblue.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>JUGUEMOS JUNTOS</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/couple4.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Eres mas de hacer el amor?  O de Sexo desenfrenado?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c2r1\">Hacer el amor</label>\n        <input id=\"c2r1\" type=\"radio\" name=\"group991\" class=\"radio1\" />\n        <label for=\"c2r2\">Sexo desenfrenado</label>\n        <input id=\"c2r2\" type=\"radio\" name=\"group991\" class=\"radio2\" />\n        <label for=\"c2r2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row21\"   >\n      <ion-label  >Te gustan los masajes por todo el cuerpo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row22\" >\n      <ion-col >\n        <label for=\"c2l1\">SI</label>\n        <input id=\"c2l1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"c2l2\">NO  </label>\n        <input id=\"c2l2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"c2l2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\" style=\"margin-top: 7px; background: #BEDDE0;\">\n      <ion-label  >Que partes de tu cuerpo te gusta mas que te toquen y te besen? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\" style=\" background: #BEDDE0;\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col >\n\n         <ion-input class=\"iput\"  ></ion-input>\n        </ion-col>\n\n        <ion-col style=\"margin-right: 60px;\">\n\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n        </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"   >\n      <ion-label  >Que cosas te gustarían hacer y nunca has hecho?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"  style=\" background: #BEDDE0;\"  >\n      <ion-label  >Cuales son las posturas que mas te gustan?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\"  style=\" background: #BEDDE0;\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"   >\n      <ion-label  >Que parte de tu cuerpo te vuelve mas loca? Creo k no poner </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"  style=\" background: #BEDDE0;\"  >\n      <ion-label  >Tienes algún fetiche? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\"  style=\" background: #BEDDE0;\">\n      <ion-col >\n        <label for=\"c2q1\">SI</label>\n        <input id=\"c2q1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"c2q2\">NO  </label>\n        <input id=\"c2q2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"c2q3\">CUAL? </label>\n        <input id=\"c2q3\" type=\"text\" style=\"width: 130px; margin-left: 10px;\" />\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click) = \"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n  </ion-list>\n\n\n\n\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_c-level3_c-level3_module_ts.js.map