(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_s-level2_s-level2_module_ts"],{

/***/ 2271:
/*!*****************************************************!*\
  !*** ./src/app/s-level2/s-level2-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel2PageRoutingModule": () => (/* binding */ SLevel2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_level2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level2.page */ 9860);




const routes = [
    {
        path: '',
        component: _s_level2_page__WEBPACK_IMPORTED_MODULE_0__.SLevel2Page
    }
];
let SLevel2PageRoutingModule = class SLevel2PageRoutingModule {
};
SLevel2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SLevel2PageRoutingModule);



/***/ }),

/***/ 4330:
/*!*********************************************!*\
  !*** ./src/app/s-level2/s-level2.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel2PageModule": () => (/* binding */ SLevel2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level2-routing.module */ 2271);
/* harmony import */ var _s_level2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level2.page */ 9860);







let SLevel2PageModule = class SLevel2PageModule {
};
SLevel2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__.SLevel2PageRoutingModule
        ],
        declarations: [_s_level2_page__WEBPACK_IMPORTED_MODULE_1__.SLevel2Page]
    })
], SLevel2PageModule);



/***/ }),

/***/ 9860:
/*!*******************************************!*\
  !*** ./src/app/s-level2/s-level2.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel2Page": () => (/* binding */ SLevel2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_level2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-level2.page.html */ 1459);
/* harmony import */ var _s_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level2.page.scss */ 2111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let SLevel2Page = class SLevel2Page {
    constructor(router, alert) {
        this.router = router;
        this.alert = alert;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['s-level3']);
    }
    alert1() {
        this.alert.applealertred();
    }
};
SLevel2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
SLevel2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-s-level2',
        template: _raw_loader_s_level2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SLevel2Page);



/***/ }),

/***/ 2111:
/*!*********************************************!*\
  !*** ./src/app/s-level2/s-level2.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pink.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 22px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #CE0647;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list2 {\n  margin-top: 10px;\n  font-size: 12px;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n}\n\n.list2 .row1 {\n  background: #F5D0D0;\n  padding: 15px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .row2 {\n  justify-content: center;\n  padding: 15px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtbGV2ZWwyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxxRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUlBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7RUFDRix1QkFBQTtBQURGOztBQUVJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUFSOztBQUVNO0VBRUUsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQURSOztBQUdNO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDRixxQkFBQTtBQUROIiwiZmlsZSI6InMtbGV2ZWwyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL3NjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG4gIFxyXG4gIFxyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9oZWFkZXJcXCBwaW5rLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcbiAgXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjQ0UwNjQ3O1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG5cclxuLmxpc3Qye1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLnJvdzF7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI0Y1RDBEMDtcclxuICAgICAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgfVxyXG4gICAgICAucm93MntcclxuICAgICAgICAvL2JhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZzogMTVweDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIH1cclxuICAgICAgLmJ0biB7XHJcbiAgICAgICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgICAgIGhlaWdodDogMzBweDtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG4gICAgICBcclxuICAgICAgXHJcbiAgICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ 1459:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-level2/s-level2.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-buttons  slot=\"end\" style = \"margin-top: -18px;\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logored.svg\" alt=\"\">\n      </ion-list>\n      <img style=\"position: absolute;bottom: -10px; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\" (click)=\"profile()\">\n\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/gmlevel2.png\" alt=\"\">\n    </ion-row>\n    </ion-list>\n    <ion-list class=\"list2\">\n      <ion-row class=\"row1\" (click)=\"alert1()\">\n        ¿Eres mas dominante o dominada?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Que es lo que mas te excita en el sexo?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\" (click)=\"alert1()\">\n        ¿Te gusta probar cosas nuevas en la cama?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Tienes fantasias con otras personas que no sean tu pareja?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row1\" (click)=\"alert1()\">\n        ¿Cuáles son tus gustos en el sexo?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Cuál es tu postura sexual favorita?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row1\" (click)=\"alert1()\">\n        ¿Llegas al orgasmo con la penetración?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Llegas al orgasmo con la estimulación en el clítoris?****\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row1\" (click)=\"alert1()\">\n        SABES, DÓNDE Y CÓMO ME GUSTA!\n        PERO TENGO MÁS.... ¿QUIERES SABER?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        <ion-button class=\"btn\" shape=\"round\" (click) = \"goto()\">SIGAMOS</ion-button>\n      </ion-row>\n    </ion-list>\n\n\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_s-level2_s-level2_module_ts.js.map