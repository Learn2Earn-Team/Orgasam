(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_m-level3_m-level3_module_ts"],{

/***/ 1606:
/*!*****************************************************!*\
  !*** ./src/app/m-level3/m-level3-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel3PageRoutingModule": () => (/* binding */ MLevel3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _m_level3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level3.page */ 7281);




const routes = [
    {
        path: '',
        component: _m_level3_page__WEBPACK_IMPORTED_MODULE_0__.MLevel3Page
    }
];
let MLevel3PageRoutingModule = class MLevel3PageRoutingModule {
};
MLevel3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MLevel3PageRoutingModule);



/***/ }),

/***/ 7967:
/*!*********************************************!*\
  !*** ./src/app/m-level3/m-level3.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel3PageModule": () => (/* binding */ MLevel3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _m_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level3-routing.module */ 1606);
/* harmony import */ var _m_level3_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level3.page */ 7281);







let MLevel3PageModule = class MLevel3PageModule {
};
MLevel3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _m_level3_routing_module__WEBPACK_IMPORTED_MODULE_0__.MLevel3PageRoutingModule
        ],
        declarations: [_m_level3_page__WEBPACK_IMPORTED_MODULE_1__.MLevel3Page]
    })
], MLevel3PageModule);



/***/ }),

/***/ 7281:
/*!*******************************************!*\
  !*** ./src/app/m-level3/m-level3.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel3Page": () => (/* binding */ MLevel3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_m_level3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./m-level3.page.html */ 8607);
/* harmony import */ var _m_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level3.page.scss */ 2850);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let MLevel3Page = class MLevel3Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['s-level']);
    }
};
MLevel3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
MLevel3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-m-level3',
        template: _raw_loader_m_level3_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_m_level3_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MLevel3Page);



/***/ }),

/***/ 2850:
/*!*********************************************!*\
  !*** ./src/app/m-level3/m-level3.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.row16 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row17 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.row21 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row22 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm0tbGV2ZWwzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBQ0k7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUNJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUNOOztBQUVJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBRk47O0FBSUk7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSE47O0FBU0U7RUFDRSxhQUFBO0FBTko7O0FBUUU7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUxKOztBQU9FO0VBQ0UseUJBQUE7QUFKSjs7QUFPRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSko7O0FBT0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUpKOztBQU9FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFKSjs7QUFPRTtFQUNFLGVBQUE7RUFFQSxrQkFBQTtFQUNBLHVCQUFBO0FBTEo7O0FBU0U7RUFFRSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsZ0JBQUE7QUFSSjs7QUFXRTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0YscUJBQUE7QUFSRjs7QUFZRTtFQUNDLGdCQUFBO0VBRUMsdUJBQUE7QUFWSjs7QUFhRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFWSjs7QUFZSTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQVROOztBQVdFO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtBQVRKOztBQVlFO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBWEo7O0FBZUU7RUFDRSxlQUFBO0VBRUEsa0JBQUE7RUFDQSx1QkFBQTtBQWJKOztBQWdCRTtFQUVJLGtCQUFBO0VBQ0EsdUJBQUE7RUFFQSxnQkFBQTtBQWZOIiwiZmlsZSI6Im0tbGV2ZWwzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL3NjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuXHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi4vLi4vYXNzZXRzL2hlYWRlclxcIHNreS5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIC5saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICMzNkQzRTE7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgfVxyXG4gICAgLnJvdzJ7XHJcblxyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgICAgbWFyZ2luLXRvcDogLTVweDtcclxuICAgIH1cclxuICAgIC5sYWJse1xyXG5cclxuICAgICAgbWFyZ2luLWxlZnQ6IDMuNXB4O1xyXG4gICAgICBtYXJnaW4tcmlnaHQ6IDMuNXB4O1xyXG5cclxuICAgIH1cclxuXHJcblxyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luOiAwIDAuNWVtO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjREMzNDYxO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzIgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8zICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJvdzN7XHJcbiAgICBtYXJnaW4tdG9wOiA3cHg7XHJcblxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgLnJvdzR7XHJcblxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuXHJcbiAgfVxyXG4gIC5idG4ge1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcblxyXG4gIH1cclxuICAucm93OHtcclxuICAgbWFyZ2luLXRvcDogMTVweDtcclxuXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC50ZXh0MXtcclxuICAgIHBhZGRpbmctbGVmdDogNTBweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDUwcHg7XHJcbiAgICB9XHJcbiAgICBpb24taW5wdXQge1xyXG4gICAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6cmdiKDI1NSwgMjU1LCAyNTUpXHJcbiAgICB9XHJcbiAgLnJvdzE2e1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzE3e1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuXHJcbiAgLnJvdzIxe1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzIye1xyXG5cclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiJdfQ== */");

/***/ }),

/***/ 8607:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/m-level3/m-level3.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logored.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/m-level3.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te disfrazarías como fantasía sexual? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m3r1\">SI</label>\n        <input id=\"m3r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n        <label for=\"m3r2\">NO</label>\n        <input id=\"m3r2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n        <label for=\"m3r2\"></label>\n\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row21\"   >\n      <ion-label  >Tienes algún fetiche?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row22\" >\n      <ion-col >\n        <label for=\"m3l1\">SI</label>\n        <input id=\"m3l1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"m3l2\">NO  </label>\n        <input id=\"m3l2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"m3l3\">CUAL</label>\n        <input id=\"m3l3\" type=\"text\" style=\"width: 90px; margin-left: 10px;\" />\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\" style=\"margin-top: 7px; background: #BEDDE0;\">\n      <ion-label  >Has probado el cibersexo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\" style=\" background: #BEDDE0;\">\n      <ion-col >\n        <label for=\"m3q1\">SI</label>\n        <input id=\"m3q1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"m3q2\">NO</label>\n        <input id=\"m3q2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"m3q2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"   >\n      <ion-label  >Que cosas te gustarían hacer y nunca has hecho?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"  style=\" background: #BEDDE0;\"  >\n      <ion-label  >Cuales son las posturas que mas te gustan?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\"  style=\" background: #BEDDE0;\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\"   >\n      <ion-label  >Cuales son las posturas que no te gustan? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"  style=\" background: #BEDDE0;\"  >\n      <ion-label  >Te consideras Vaginal o Clitórica? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\"  style=\" background: #BEDDE0;\">\n      <ion-col >\n        <label for=\"m3w1\">O ambas VAGINAL</label>\n        <input id=\"m3w1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"m3w2\">CLITÓRICA</label>\n        <input id=\"m3w2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"m3w3\">AMBAS</label>\n        <input id=\"m3w3\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"m3w3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row16\" style=\"margin-top: 7px;\">\n      <ion-label  >Te gusta probar cosas nuevas en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row17\">\n      <ion-col >\n        <label for=\"m3e1\">SI</label>\n        <input id=\"m3e1\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"m3e2\">NO</label>\n        <input id=\"m3e2\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"m3e2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n  </ion-list>\n\n\n\n\n\n</ion-content>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_m-level3_m-level3_module_ts.js.map