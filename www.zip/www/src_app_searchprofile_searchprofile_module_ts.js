(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_searchprofile_searchprofile_module_ts"],{

/***/ 8367:
/*!***************************************************************!*\
  !*** ./src/app/searchprofile/searchprofile-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchprofilePageRoutingModule": () => (/* binding */ SearchprofilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _searchprofile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./searchprofile.page */ 1758);




const routes = [
    {
        path: '',
        component: _searchprofile_page__WEBPACK_IMPORTED_MODULE_0__.SearchprofilePage
    }
];
let SearchprofilePageRoutingModule = class SearchprofilePageRoutingModule {
};
SearchprofilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SearchprofilePageRoutingModule);



/***/ }),

/***/ 9283:
/*!*******************************************************!*\
  !*** ./src/app/searchprofile/searchprofile.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchprofilePageModule": () => (/* binding */ SearchprofilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _searchprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./searchprofile-routing.module */ 8367);
/* harmony import */ var _searchprofile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./searchprofile.page */ 1758);







let SearchprofilePageModule = class SearchprofilePageModule {
};
SearchprofilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _searchprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__.SearchprofilePageRoutingModule
        ],
        declarations: [_searchprofile_page__WEBPACK_IMPORTED_MODULE_1__.SearchprofilePage]
    })
], SearchprofilePageModule);



/***/ }),

/***/ 1758:
/*!*****************************************************!*\
  !*** ./src/app/searchprofile/searchprofile.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchprofilePage": () => (/* binding */ SearchprofilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_searchprofile_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./searchprofile.page.html */ 8326);
/* harmony import */ var _searchprofile_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./searchprofile.page.scss */ 9870);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let SearchprofilePage = class SearchprofilePage {
    constructor() { }
    ngOnInit() {
    }
};
SearchprofilePage.ctorParameters = () => [];
SearchprofilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-searchprofile',
        template: _raw_loader_searchprofile_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_searchprofile_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SearchprofilePage);



/***/ }),

/***/ 9870:
/*!*******************************************************!*\
  !*** ./src/app/searchprofile/searchprofile.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('header Pr.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E06082;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list2 {\n  background: #DE5C7C;\n  padding: 9px;\n  margin-top: 10px;\n}\n\n.list2 .row1 {\n  justify-content: center;\n}\n\n.list2 .row1 .input1 {\n  margin-left: 5px;\n  width: 270px;\n  border-radius: 17px;\n  height: 32px;\n  border-color: transparent;\n}\n\n.list3 {\n  margin-top: 10px;\n  background: #E3B8C4;\n  height: 106px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list4_label1 {\n  font-size: 15px;\n  font-weight: bold;\n  margin-left: 10%;\n}\n\n.list4_label2 {\n  font-size: 15px;\n  font-weight: bold;\n  color: #DC3461;\n  margin-left: 10%;\n}\n\n.list4_label3 {\n  font-size: 10px;\n  font-weight: bold;\n  color: #E4E4E4;\n  background: #CA063A;\n  padding: 6px;\n  padding-right: 15px;\n  margin-right: 20px;\n  border-radius: 13px;\n}\n\n.list4_label4 {\n  font-size: 8px;\n  font-weight: bold;\n  color: #E4E4E4;\n  background: #CA063A;\n  padding: 6px;\n  padding-right: 15px;\n  border-radius: 13px;\n  margin-left: 60%;\n}\n\n.avatar3 {\n  height: 66px;\n  width: 66px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaHByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsbUVBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSx1QkFBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUVBO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFBSTtFQUNJLHVCQUFBO0FBRVI7O0FBRFE7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtBQUdaOztBQUNBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxnQ0FBQTtBQUVKOztBQUFFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFHSjs7QUFERTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQUlKOztBQUZFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUtKOztBQUhFO0VBQ0csY0FBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0QsWUFBQTtFQUNBLG1CQUFBO0VBQ0MsbUJBQUE7RUFDQSxnQkFBQTtBQU1MOztBQUpHO0VBQ0MsWUFBQTtFQUNBLFdBQUE7QUFPSiIsImZpbGUiOiJzZWFyY2hwcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL3NjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4vLi4vLi4vYXNzZXRzL2hlYWRlclxcIFByLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjRTA2MDgyO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbn1cclxuLmxpc3Qye1xyXG4gICAgYmFja2dyb3VuZDogI0RFNUM3QztcclxuICAgIHBhZGRpbmc6IDlweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAucm93MXtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAuaW5wdXQxe1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgICAgICAgICB3aWR0aDogMjcwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE3cHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzJweDtcclxuICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuLmxpc3Qze1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIGJhY2tncm91bmQ6ICNFM0I4QzQ7XHJcbiAgICBoZWlnaHQ6IDEwNnB4O1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgfVxyXG4gIC5saXN0NF9sYWJlbDF7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgfVxyXG4gIC5saXN0NF9sYWJlbDJ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiAjREMzNDYxO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICB9XHJcbiAgLmxpc3Q0X2xhYmVsM3tcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6ICNFNEU0RTQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjQ0EwNjNBO1xyXG4gICAgcGFkZGluZzogNnB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTVweDtcclxuICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEzcHg7XHJcbiAgfVxyXG4gIC5saXN0NF9sYWJlbDR7XHJcbiAgICAgZm9udC1zaXplOiA4cHg7XHJcbiAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgY29sb3I6ICNFNEU0RTQ7XHJcbiAgICAgYmFja2dyb3VuZDogI0NBMDYzQTtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICAgYm9yZGVyLXJhZGl1czogMTNweDtcclxuICAgICBtYXJnaW4tbGVmdDogNjAlO1xyXG4gICB9XHJcbiAgIC5hdmF0YXIze1xyXG4gICAgaGVpZ2h0OiA2NnB4O1xyXG4gICAgd2lkdGg6IDY2cHg7XHJcbiAgfVxyXG4iXX0= */");

/***/ }),

/***/ 8326:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/searchprofile/searchprofile.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n    <!-- <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\"> -->\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n    </ion-list>\n    <ion-list class=\"list2\">\n      <ion-row class=\"row1\">\n        <img class=\"logo1\" src=\"./../../assets/search.svg\">\n        <input type=\"text\" class=\"input1\" />\n      </ion-row>\n\n    </ion-list>\n\n    <ion-list class=\"list3\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size =\"2\">\n            <ion-avatar class= \"avatar3\">\n              <img  src=\"assets/person.png\">\n            </ion-avatar>\n          </ion-col>\n          <ion-col siz = \"12\">\n            <ion-label class = \"list4_label1\">\n              SIMÓN LOPEZ SIERRA\n            </ion-label><br>\n            <ion-label class=\"list4_label2\">\n              SOLTERO / HETEROSEXUAL\n            </ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row style = \"justify-content: flex-end; margin-top: -10px\">\n          <ion-label class=\"list4_label4\">\n            Negar  Solicitud\n          </ion-label>\n        </ion-row>\n      </ion-grid>\n      </ion-list>\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_searchprofile_searchprofile_module_ts.js.map