(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_s-level1_s-level1_module_ts"],{

/***/ 7850:
/*!*****************************************************!*\
  !*** ./src/app/s-level1/s-level1-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel1PageRoutingModule": () => (/* binding */ SLevel1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_level1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level1.page */ 5859);




const routes = [
    {
        path: '',
        component: _s_level1_page__WEBPACK_IMPORTED_MODULE_0__.SLevel1Page
    }
];
let SLevel1PageRoutingModule = class SLevel1PageRoutingModule {
};
SLevel1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SLevel1PageRoutingModule);



/***/ }),

/***/ 6762:
/*!*********************************************!*\
  !*** ./src/app/s-level1/s-level1.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel1PageModule": () => (/* binding */ SLevel1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level1-routing.module */ 7850);
/* harmony import */ var _s_level1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level1.page */ 5859);







let SLevel1PageModule = class SLevel1PageModule {
};
SLevel1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__.SLevel1PageRoutingModule
        ],
        declarations: [_s_level1_page__WEBPACK_IMPORTED_MODULE_1__.SLevel1Page]
    })
], SLevel1PageModule);



/***/ }),

/***/ 5859:
/*!*******************************************!*\
  !*** ./src/app/s-level1/s-level1.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevel1Page": () => (/* binding */ SLevel1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_level1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-level1.page.html */ 6387);
/* harmony import */ var _s_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level1.page.scss */ 4341);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let SLevel1Page = class SLevel1Page {
    constructor(router, alert) {
        this.router = router;
        this.alert = alert;
    }
    ngOnInit() {
    }
    alert1() {
        this.alert.applealertred();
    }
    goto() {
        this.router.navigate(['s-level2']);
    }
    profile() {
        this.router.navigate(['fprofile']);
    }
};
SLevel1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
SLevel1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-s-level1',
        template: _raw_loader_s_level1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SLevel1Page);



/***/ }),

/***/ 4341:
/*!*********************************************!*\
  !*** ./src/app/s-level1/s-level1.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pur.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #7A3E6A;\n  height: 35px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list2 {\n  margin-top: 10px;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n}\n\n.list2 .row1 {\n  background: #E3D3D4;\n  padding: 15px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .row2 {\n  justify-content: center;\n  padding: 15px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtbGV2ZWwxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7QUFBSjs7QUFFSTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUdBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7RUFDRix1QkFBQTtBQUFGOztBQUNJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUNSOztBQUNNO0VBRUUsdUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUFSOztBQUVNO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDRixxQkFBQTtBQUFOIiwiZmlsZSI6InMtbGV2ZWwxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL3NjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuXHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi4vLi4vYXNzZXRzL2hlYWRlclxcIHB1ci5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIC5saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjN0EzRTZBO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG59XHJcbi5saXN0MntcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIC5yb3cxe1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNFM0QzRDQ7XHJcbiAgICAgICAgcGFkZGluZzogMTVweDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIH1cclxuICAgICAgLnJvdzJ7XHJcbiAgICAgICAgLy9iYWNrZ3JvdW5kOiAjRTlGNjczO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICB9XHJcbiAgICAgIC5idG4ge1xyXG4gICAgICAgIHdpZHRoOiAxNTBweDtcclxuICAgICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcblxyXG4gICAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 6387:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-level1/s-level1.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-buttons  slot=\"end\" style = \"margin-top: -18px;\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logopr.svg\" alt=\"\">\n      </ion-list>\n      <img style=\"position: absolute;bottom: -10px; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\" (click)=\"profile()\">\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Has avanzado...quieres más?</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/gmlevel1.png\" alt=\"\">\n    </ion-row>\n    </ion-list>\n    <ion-list class=\"list2\">\n      <ion-row class=\"row1\">\n        ¿Te has masturbado alguna vez?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Que partes de tu cuerpo te gustan mas que te toquen?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        Que partes de tu cuerpo te gustan mas que te besen?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        Te gusta desnudarte delante de tu pareja?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        ¿Sueles usar juguetes eróticos?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Qué partes de tu cuerpo te gustan mas?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        ¿Cuales son las posturas que mas te gustan?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row2\">\n        ¿Qué no te gusta del sexo?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        YA HAS DESCUBIERTO MUCHAS COSAS DE MI, ¿SEGUIMOS JUGANDO?\n        <img style=\"position: absolute; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert1()\">\n      </ion-row>\n      <ion-row class=\"row1\">\n        <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\" >SÍ SEGUIR</ion-button>\n        <ion-button class=\"btn\" shape=\"round\" >NAH</ion-button>\n      </ion-row>\n    </ion-list>\n\n\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_s-level1_s-level1_module_ts.js.map