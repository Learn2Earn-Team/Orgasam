(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_m-level2_m-level2_module_ts"],{

/***/ 902:
/*!*****************************************************!*\
  !*** ./src/app/m-level2/m-level2-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel2PageRoutingModule": () => (/* binding */ MLevel2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _m_level2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level2.page */ 5256);




const routes = [
    {
        path: '',
        component: _m_level2_page__WEBPACK_IMPORTED_MODULE_0__.MLevel2Page
    }
];
let MLevel2PageRoutingModule = class MLevel2PageRoutingModule {
};
MLevel2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MLevel2PageRoutingModule);



/***/ }),

/***/ 6326:
/*!*********************************************!*\
  !*** ./src/app/m-level2/m-level2.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel2PageModule": () => (/* binding */ MLevel2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _m_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level2-routing.module */ 902);
/* harmony import */ var _m_level2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level2.page */ 5256);







let MLevel2PageModule = class MLevel2PageModule {
};
MLevel2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _m_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__.MLevel2PageRoutingModule
        ],
        declarations: [_m_level2_page__WEBPACK_IMPORTED_MODULE_1__.MLevel2Page]
    })
], MLevel2PageModule);



/***/ }),

/***/ 5256:
/*!*******************************************!*\
  !*** ./src/app/m-level2/m-level2.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevel2Page": () => (/* binding */ MLevel2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_m_level2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./m-level2.page.html */ 5343);
/* harmony import */ var _m_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level2.page.scss */ 1448);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let MLevel2Page = class MLevel2Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['m-level3']);
    }
};
MLevel2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
MLevel2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-m-level2',
        template: _raw_loader_m_level2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_m_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MLevel2Page);



/***/ }),

/***/ 1448:
/*!*********************************************!*\
  !*** ./src/app/m-level2/m-level2.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pink.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #CE0647;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\n.list .alert-wrapper {\n  --background: url('alert image.png') no-repeat center center / cover !important;\n  --border-radius:5px!important;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E3D3D5;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E3D3D5;\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  text-align: center;\n  justify-content: center;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.iput {\n  width: 70px;\n}\n\n.iput1 {\n  margin-right: 50px;\n}\n\n.row12 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row13 {\n  margin-top: -5px;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n\n.row15 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row16 {\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n\n.my-custom-class .alert-wrapper {\n  --background: #db1818 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm0tbGV2ZWwyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxxRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUVJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUFOOztBQUVJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRk47O0FBS0k7RUFDRSwrRUFBQTtFQUNBLDZCQUFBO0FBSE47O0FBUUU7RUFDRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UseUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBSE47O0FBTUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBSEY7O0FBT0U7RUFDQyxnQkFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7QUFMSDs7QUFRRTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQUxKOztBQU9FO0VBQ0UsV0FBQTtBQUpKOztBQVFFO0VBQ0Esa0JBQUE7QUFMRjs7QUFPRTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7QUFKSjs7QUFPRTtFQUVFLGdCQUFBO0FBTEo7O0FBU0U7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBTkY7O0FBU0U7RUFDRSxlQUFBO0VBRUEsa0JBQUE7RUFDQSx1QkFBQTtBQVBKOztBQVdFO0VBRUUsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBVE47O0FBZ0JFO0VBQ0UsZ0NBQUE7QUFiSiIsImZpbGUiOiJtLWxldmVsMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcblxyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9oZWFkZXJcXCBwaW5rLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG5cclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNDRTA2NDc7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiAgICAubGFibHtcclxuXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuXHJcbiAgICB9XHJcbiAgICAuYWxlcnQtd3JhcHBlcntcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAgdXJsKCcuLi8uLi9hc3NldHMvYWxlcnRcXCBpbWFnZS5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyICFpbXBvcnRhbnQ7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czo1cHghaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXJnaW46IDAgMC41ZW07XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbiAgfVxyXG5cclxuICAucmFkaW8xICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucm93M3tcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxuICAgIGJhY2tncm91bmQ6ICNFM0QzRDU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3c0e1xyXG4gICAgYmFja2dyb3VuZDogI0UzRDNENTtcclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLmJ0biB7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG5cclxuXHJcbiAgfVxyXG4gIC5yb3c4e1xyXG4gICBtYXJnaW4tdG9wOiAxNXB4O1xyXG5cclxuICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB9XHJcblxyXG4gIGlvbi1pbnB1dCB7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOnJnYigyNTUsIDI1NSwgMjU1KVxyXG4gIH1cclxuICAuaXB1dHtcclxuICAgIHdpZHRoOiA3MHB4O1xyXG5cclxuXHJcbiAgfVxyXG4gIC5pcHV0MXtcclxuICBtYXJnaW4tcmlnaHQ6IDUwcHg7XHJcbiAgfVxyXG4gIC5yb3cxMntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzEze1xyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuXHJcbiAgLnRleHQxe1xyXG4gIHBhZGRpbmctbGVmdDogNTBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnJvdzE1e1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcblxyXG4gIC5yb3cxNntcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB9XHJcblxyXG4gIC8vIC5teS1jdXN0b20tY2xhc3Mge1xyXG4gIC8vICAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxIWltcG9ydGFudDtcclxuICAvLyAgIC0tYm9yZGVyLXJhZGl1czo1cHghaW1wb3J0YW50O1xyXG4gIC8vIH1cclxuICAubXktY3VzdG9tLWNsYXNzIC5hbGVydC13cmFwcGVye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZGIxODE4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC8vIC5teS1jdXN0b20tY2xhc3MgLmFsZXJ0LXdyYXBwZXIge1xyXG4gIC8vICAgYmFja2dyb3VuZDogI2MyMTExMTtcclxuICAvLyB9XHJcbiJdfQ== */");

/***/ }),

/***/ 5343:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/m-level2/m-level2.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logored.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons  slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n    <ion-row>\n      <img style=\"width: 100%;\" src=\"../../assets/level/m-level2.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >¿Eres mas dominante o dominada?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m2r1\">DOMINANTE</label>\n        <input id=\"m2r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n        <label for=\"m2r2\">SUMISA</label>\n        <input id=\"m2r2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n        <label for=\"m2r2\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >¿Que es lo que mas te excita en el sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n      </ion-col>\n\n      <ion-col style=\"margin-right: 60px;\">\n\n        <ion-input class=\"iput\"></ion-input>\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" (click) = \"test()\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >¿Te gusta probar cosas nuevas en la cama?</ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m2r3\">SI </label>\n        <input id=\"m2r3\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"m2r4\">NO</label>\n        <input id=\"m2r4\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"m2r5\"> NO MUCHO</label>\n        <input id=\"m2r5\" type=\"radio\" name=\"group2\" class=\"radio3\" />\n        <label for=\"m2r5\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n\n\n\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >¿Tienes fantasias con otras personas que no sean tu pareja?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"m2r6\">SI</label>\n        <input id=\"m2r6\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"m2r7\">NO</label>\n        <input id=\"m2r7\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"m2r8\">NO MUCHO</label>\n        <input id=\"m2r8\" type=\"radio\" name=\"group3\" class=\"radio3\" />\n        <label for=\"m2r8\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >¿Cuáles son tus gustos en el sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n      </ion-col>\n\n      <ion-col style=\"margin-right: 60px;\">\n\n        <ion-input class=\"iput\"></ion-input>\n      </ion-col>\n      <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >¿Cuál es tu postura sexual favorita? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\" style=\"background-color: #E3D3D5;\">\n      <ion-col>\n\n        <div class=\"text1\">\n\n\n\n\n          <ion-input class=\"nput1\"    ></ion-input>\n\n        </div>\n\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n\n    </ion-row>\n\n    <ion-row  class=\"row1\"   >\n      <ion-label  >¿Llegas al orgasmo con la penetración?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"m2r9\">SI</label>\n        <input id=\"m2r9\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"m2r10\">NO</label>\n        <input id=\"m2r10\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"m2r11\">NO MUCHO</label>\n        <input id=\"m2r11\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"m2r11\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label style=\"margin-left: 40px; margin-right: 40px;\" >¿Llegas al orgasmo con la estimulación en el clítoris?****</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"m2r12\">SI</label>\n        <input id=\"m2r12\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"m2r13\">NO</label>\n        <input id=\"m2r13\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"m2r14\">NO MUCHO</label>\n        <input id=\"m2r14\" type=\"radio\" name=\"group5\" class=\"radio3\" />\n        <label for=\"m2r14\"></label>\n\n        <img  style=\"position: absolute; bottom: 0; right: 1; margin: 10px;\" src=\"../../assets/pluse.svg\" alt=\"\">\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n\n    </ion-row>\n\n\n\n\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n\n  </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_m-level2_m-level2_module_ts.js.map