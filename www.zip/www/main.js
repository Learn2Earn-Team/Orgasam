(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);



const routes = [
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 3467)).then(m => m.HomePageModule)
    },
    {
        path: '',
        redirectTo: 'ligin1',
        pathMatch: 'full'
    },
    {
        path: 'tutorial',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tutorial_tutorial_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tutorial/tutorial.module */ 1494)).then(m => m.TutorialPageModule)
    },
    {
        path: 'tutorial2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tutorial2_tutorial2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tutorial2/tutorial2.module */ 1140)).then(m => m.Tutorial2PageModule)
    },
    {
        path: 'ligin1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_ligin1_ligin1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./ligin1/ligin1.module */ 6111)).then(m => m.Ligin1PageModule)
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 107)).then(m => m.LoginPageModule)
    },
    {
        path: 'f-level',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_f-level_f-level_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./f-level/f-level.module */ 4093)).then(m => m.FLevelPageModule)
    },
    {
        path: 'fprofile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_fprofile_fprofile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./fprofile/fprofile.module */ 6286)).then(m => m.FprofilePageModule)
    },
    {
        path: 'f-level1',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_f-level1_f-level1_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./f-level1/f-level1.module */ 8089)).then(m => m.FLevel1PageModule)
    },
    {
        path: 'f-level2',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_f-level2_f-level2_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./f-level2/f-level2.module */ 5108)).then(m => m.FLevel2PageModule)
    },
    {
        path: 'f-level3',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_f-level3_f-level3_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./f-level3/f-level3.module */ 9061)).then(m => m.FLevel3PageModule)
    },
    {
        path: 'searchprofile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_searchprofile_searchprofile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./searchprofile/searchprofile.module */ 9283)).then(m => m.SearchprofilePageModule)
    },
    {
        path: 'fprofilelevel',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_fprofilelevel_fprofilelevel_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./fprofilelevel/fprofilelevel.module */ 3345)).then(m => m.FprofilelevelPageModule)
    },
    {
        path: 'mprofilelevel',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_mprofilelecel_mprofilelecel_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./mprofilelecel/mprofilelecel.module */ 9103)).then(m => m.MprofilelecelPageModule)
    },
    {
        path: 'm-level',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_m-level_m-level_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./m-level/m-level.module */ 7003)).then(m => m.MLevelPageModule)
    },
    {
        path: 'm-level1',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_m-level1_m-level1_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./m-level1/m-level1.module */ 9382)).then(m => m.MLevel1PageModule)
    },
    {
        path: 'm-level2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_m-level2_m-level2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./m-level2/m-level2.module */ 6326)).then(m => m.MLevel2PageModule)
    },
    {
        path: 'm-level3',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_m-level3_m-level3_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./m-level3/m-level3.module */ 7967)).then(m => m.MLevel3PageModule)
    },
    {
        path: 's-level',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_s-level_s-level_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./s-level/s-level.module */ 1072)).then(m => m.SLevelPageModule)
    },
    {
        path: 's-level1',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_s-level1_s-level1_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./s-level1/s-level1.module */ 6762)).then(m => m.SLevel1PageModule)
    },
    {
        path: 's-level2',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_s-level2_s-level2_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./s-level2/s-level2.module */ 4330)).then(m => m.SLevel2PageModule)
    },
    {
        path: 's-level3',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_s-level3_s-level3_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./s-level3/s-level3.module */ 9425)).then(m => m.SLevel3PageModule)
    },
    {
        path: 'c-level',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_c-level_c-level_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./c-level/c-level.module */ 7781)).then(m => m.CLevelPageModule)
    },
    {
        path: 'c-level1',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_c-level1_c-level1_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./c-level1/c-level1.module */ 8421)).then(m => m.CLevel1PageModule)
    },
    {
        path: 'c-level2',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_c-level2_c-level2_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./c-level2/c-level2.module */ 7114)).then(m => m.CLevel2PageModule)
    },
    {
        path: 'c-level3',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_c-level3_c-level3_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./c-level3/c-level3.module */ 9451)).then(m => m.CLevel3PageModule)
    },
    {
        path: 'shop',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_shop_shop_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./shop/shop.module */ 7838)).then(m => m.ShopPageModule)
    },
    {
        path: 'pay',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pay_pay_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pay/pay.module */ 9485)).then(m => m.PayPageModule)
    },
    {
        path: 'blackcastle',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_blackcastle_blackcastle_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./blackcastle/blackcastle.module */ 4569)).then(m => m.BlackcastlePageModule)
    },
    {
        path: 'c-levellast',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_c-levellast_c-levellast_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./c-levellast/c-levellast.module */ 1597)).then(m => m.CLevellastPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 1106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 3069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let AppComponent = class AppComponent {
    constructor(router) {
        this.router = router;
    }
    profile() {
        this.router.navigate(['fprofile']);
    }
    tutorial() {
        this.router.navigate(['home']);
    }
    login() {
        this.router.navigate(['login']);
    }
    shop() {
        this.router.navigate(['shop']);
    }
};
AppComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyHammerGestureConfig": () => (/* binding */ MyHammerGestureConfig),
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! hammerjs */ 1524);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_2__);









class MyHammerGestureConfig extends _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.HammerGestureConfig {
    constructor() {
        super(...arguments);
        this.overrides = {
            swipe: { direction: hammerjs__WEBPACK_IMPORTED_MODULE_2__.DIRECTION_ALL }
        };
    }
}
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicRouteStrategy }, { provide: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.HAMMER_GESTURE_CONFIG, useClass: MyHammerGestureConfig }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! hammerjs */ 1524);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_2__);





if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_4__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		7321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		6108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		1489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		5830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		7757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		6911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		8695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		6034,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		1709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		5931,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		4513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		1855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		8708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		3527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		9222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		9921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		3122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		1602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		6164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		7162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		7896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		5043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		7802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		9072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		2191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		7110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 3069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-menu {\n  height: 400px;\n  --width: 200px;\n  margin-top: 50px;\n}\n\nion-list {\n  background: transparent;\n}\n\nion-button {\n  --background: #CE0647;\n  height: 30px;\n  font-size: 18px;\n  font-family: Montserrat-SemiBold;\n}\n\nion-content {\n  --background: #F55B8E;\n}\n\n.up {\n  height: 60px;\n}\n\n.btn {\n  margin-top: 20px;\n}\n\n.btn1 {\n  position: absolute;\n  bottom: 0;\n  margin-bottom: 20px;\n  width: 100%;\n}\n\nimg {\n  position: absolute;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFDSTtFQUNFLHVCQUFBO0FBRU47O0FBQUk7RUFDRSxxQkFBQTtFQUNFLFlBQUE7RUFDRixlQUFBO0VBQ0EsZ0NBQUE7QUFHTjs7QUFESTtFQUNFLHFCQUFBO0FBSU47O0FBRkk7RUFDRSxZQUFBO0FBS047O0FBRkk7RUFDRSxnQkFBQTtBQUtOOztBQUhJO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBTUo7O0FBSkk7RUFDRSxrQkFBQTtFQUNBLFFBQUE7QUFPTiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudXtcclxuICAgIGhlaWdodDogNDAwcHg7XHJcbiAgICAtLXdpZHRoOiAyMDBweDtcclxuICAgIG1hcmdpbi10b3A6IDUwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdHtcclxuICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICNDRTA2NDc7XHJcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgfVxyXG4gICAgaW9uLWNvbnRlbnR7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogI0Y1NUI4RTtcclxuICAgIH1cclxuICAgIC51cHtcclxuICAgICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgfVxyXG5cclxuICAgIC5idG57XHJcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB9XHJcbiAgICAuYnRuMXtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIGltZ3tcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogMDtcclxuICAgIH1cclxuIl19 */");

/***/ }),

/***/ 1106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu  side=\"end\"  contentId=\"main-content\" type=\"overlay\"  >\n      <ion-content >\n         <div class=\"up\">\n\n         </div>\n\n        <ion-list id=\"labels-list\">\n          <ion-button class=\"btn\" expand=\"full\" (click)=\"profile()\">Perfil</ion-button>\n          <ion-button class=\"btn\" expand=\"full\" (click)=\"tutorial()\">Tutorial</ion-button>\n          <ion-button class=\"btn\" expand=\"full\">Políticas </ion-button>\n          <ion-button class=\"btn\" expand=\"full\" (click)=\"shop()\">Compra de<img  src=\"../assets/began logo.svg\" alt=\"\"></ion-button>\n\n\n\n        </ion-list>\n        <ion-button class=\"btn1\" expand=\"full\" (click)=\"login()\">Cerrar Sesión</ion-button>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map