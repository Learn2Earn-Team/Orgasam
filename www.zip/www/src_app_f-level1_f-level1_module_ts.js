(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_f-level1_f-level1_module_ts"],{

/***/ 3742:
/*!*****************************************************!*\
  !*** ./src/app/f-level1/f-level1-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevel1PageRoutingModule": () => (/* binding */ FLevel1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _f_level1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./f-level1.page */ 4838);




const routes = [
    {
        path: '',
        component: _f_level1_page__WEBPACK_IMPORTED_MODULE_0__.FLevel1Page
    }
];
let FLevel1PageRoutingModule = class FLevel1PageRoutingModule {
};
FLevel1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FLevel1PageRoutingModule);



/***/ }),

/***/ 8089:
/*!*********************************************!*\
  !*** ./src/app/f-level1/f-level1.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevel1PageModule": () => (/* binding */ FLevel1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _f_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./f-level1-routing.module */ 3742);
/* harmony import */ var _f_level1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./f-level1.page */ 4838);







let FLevel1PageModule = class FLevel1PageModule {
};
FLevel1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _f_level1_routing_module__WEBPACK_IMPORTED_MODULE_0__.FLevel1PageRoutingModule
        ],
        declarations: [_f_level1_page__WEBPACK_IMPORTED_MODULE_1__.FLevel1Page]
    })
], FLevel1PageModule);



/***/ }),

/***/ 4838:
/*!*******************************************!*\
  !*** ./src/app/f-level1/f-level1.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevel1Page": () => (/* binding */ FLevel1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_f_level1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./f-level1.page.html */ 71);
/* harmony import */ var _f_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./f-level1.page.scss */ 1936);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let FLevel1Page = class FLevel1Page {
    constructor(router, alert1) {
        this.router = router;
        this.alert1 = alert1;
    }
    ngOnInit() {
    }
    level2() {
        this.router.navigate(['f-level2']);
    }
    alert() {
        this.alert1.simplealertred();
    }
    alert2() {
        this.alert1.blueslidealert();
    }
    profile() {
        this.router.navigate(['fprofilelevel']);
    }
};
FLevel1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
FLevel1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-f-level1',
        template: _raw_loader_f_level1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_f_level1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FLevel1Page);



/***/ }),

/***/ 1936:
/*!*********************************************!*\
  !*** ./src/app/f-level1/f-level1.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pur.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 22px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #7A3E6A;\n  height: 35px;\n  color: white;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  font-size: 15px;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E3D3D5;\n  text-align: center;\n  justify-content: center;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n}\n\n.row4 {\n  background: #E3D3D5;\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  text-align: center;\n  justify-content: center;\n  font-size: 12px;\n  font-family: Montserrat-SemiBold;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.iput {\n  width: 70px;\n}\n\n.iput1 {\n  margin-right: 50px;\n}\n\n.row12 {\n  text-align: center;\n  justify-content: center;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n}\n\n.row13 {\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n  margin-top: -5px;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImYtbGV2ZWwxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxvRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBR0k7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBRE47O0FBR0k7RUFDRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdDQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBRk47O0FBSUk7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSE47O0FBU0U7RUFFRSxhQUFBO0FBUEo7O0FBU0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFFO0VBQ0UseUJBQUE7QUFMSjs7QUFRRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBTEo7O0FBUUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUxKOztBQVFFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFMSjs7QUFRRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7QUFMSjs7QUFPRTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdDQUFBO0FBSk47O0FBT0U7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBSkY7O0FBUUU7RUFDQyxnQkFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7QUFOSDs7QUFTRTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQU5KOztBQVFFO0VBQ0UsV0FBQTtBQUxKOztBQVNFO0VBQ0Esa0JBQUE7QUFORjs7QUFRRTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7QUFMSjs7QUFPRTtFQUVFLGVBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0FBTEo7O0FBU0U7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBTkYiLCJmaWxlIjoiZi1sZXZlbDEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgcHVyLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG5cclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjN0EzRTZBO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MXtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgIH1cclxuICAgIC5yb3cye1xyXG5cclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4gICAgLmxhYmx7XHJcblxyXG4gICAgICBtYXJnaW4tbGVmdDogMy41cHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogMy41cHg7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuXHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luOiAwIDAuNWVtO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjREMzNDYxO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzIgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8zICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJvdzN7XHJcbiAgICBtYXJnaW4tdG9wOiA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTNEM0Q1O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICB9XHJcbiAgLnJvdzR7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTNEM0Q1O1xyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcblxyXG4gIH1cclxuICAuYnRuIHtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICB9XHJcbiAgLnJvdzh7XHJcbiAgIG1hcmdpbi10b3A6IDE1cHg7XHJcblxyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICBmb250LXNpemU6IDEycHg7XHJcbiAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIH1cclxuXHJcbiAgaW9uLWlucHV0IHtcclxuICAgIGhlaWdodDogMjBweDtcclxuICAgIGJhY2tncm91bmQ6cmdiKDI1NSwgMjU1LCAyNTUpXHJcbiAgfVxyXG4gIC5pcHV0e1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcblxyXG5cclxuICB9XHJcbiAgLmlwdXQxe1xyXG4gIG1hcmdpbi1yaWdodDogNTBweDtcclxuICB9XHJcbiAgLnJvdzEye1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICB9XHJcbiAgLnJvdzEze1xyXG5cclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuXHJcbiAgfVxyXG5cclxuICAudGV4dDF7XHJcbiAgcGFkZGluZy1sZWZ0OiA1MHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDUwcHg7XHJcbiAgfVxyXG5cclxuXHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ 71:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/f-level1/f-level1.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-buttons  slot=\"end\" style = \"margin-top: -18px;\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logopr.svg\" alt=\"\">\n      </ion-list>\n      <img style=\"position: absolute;bottom: -10px; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\" (click)=\"profile()\">\n\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/girl1.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te has masturbado alguna vez?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"f1r1\">SI</label>\n        <input id=\"f1r1\" type=\"radio\" name=\"group221\" class=\"radio1\" />\n        <label for=\"f1r2\">NO</label>\n        <input id=\"f1r2\" type=\"radio\" name=\"group221\" class=\"radio2\" />\n        <label for=\"f1r2\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que partes de tu cuerpo te gustan mas que te toquen?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n       <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n      </ion-col>\n      <ion-col >\n\n        <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n\n       <ion-col style=\"margin-right: 60px;\">\n\n        <ion-input class=\"iput\"></ion-input>\n       </ion-col>\n       <ion-col>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n       </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Que partes de tu cuerpo te gustan mas que te besen? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col >\n\n         <ion-input class=\"iput\"  ></ion-input>\n        </ion-col>\n\n        <ion-col style=\"margin-right: 60px;\">\n\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n\n        </ion-col>\n\n\n\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Sueles usar juguetes eróticos? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n        <label for=\"f1l1\">SI</label>\n        <input id=\"f1l1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"f1l2\">NO</label>\n        <input id=\"f1l2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"f1l2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert2()\">\n        </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te gusta que te aten en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"f1k1\">SI</label>\n        <input id=\"f1k1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"f1k2\">NO</label>\n        <input id=\"f1k2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"f1k2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert()\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\" >\n      <ion-label  >Te gusta usar las esposas?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"f1m1\">SI</label>\n        <input id=\"f1m1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"f1m2\">NO</label>\n        <input id=\"f1m2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"f1m2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert()\">\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gusta que te tiren del pelo mientras tienes sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\" style=\"background-color: #E3D3D5;\">\n      <ion-col >\n        <label for=\"f1p1\">SI</label>\n        <input id=\"f1p1\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"f1p2\">NO  </label>\n        <input id=\"f1p2\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"f1p2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert()\">\n      </ion-col>\n    </ion-row>\n\n\n\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Te gusta que te exciten con palabras? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"f1o1\">SI</label>\n        <input id=\"f1o1\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"f1o2\">NO  </label>\n        <input id=\"f1o2\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"f1o2\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert2()\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que es lo mas importante para ti en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col style=\"margin-left: 60px;\" >\n\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col >\n\n         <ion-input class=\"iput\"  ></ion-input>\n        </ion-col>\n\n        <ion-col>\n\n         <ion-input class=\"iput\"></ion-input>\n\n        </ion-col>\n        <ion-col>\n          <img src=\"../../assets/pluse.svg\" alt=\"\">\n        </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\" (click)=\"alert()\">\n\n        </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row12\"   >\n      <ion-label  >Que cosas no te gustan en el sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row13\">\n      <ion-col>\n\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"></ion-input>\n\n        </div>\n\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\" (click)=\"alert2()\">\n       </ion-col>\n\n    </ion-row>\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"level2()\" >FINALIZAR</ion-button>\n    </ion-row>\n\n  </ion-list>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_f-level1_f-level1_module_ts.js.map