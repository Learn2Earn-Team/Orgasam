(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_shop_shop_module_ts"],{

/***/ 8098:
/*!*********************************************!*\
  !*** ./src/app/shop/shop-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShopPageRoutingModule": () => (/* binding */ ShopPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _shop_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shop.page */ 900);




const routes = [
    {
        path: '',
        component: _shop_page__WEBPACK_IMPORTED_MODULE_0__.ShopPage
    }
];
let ShopPageRoutingModule = class ShopPageRoutingModule {
};
ShopPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ShopPageRoutingModule);



/***/ }),

/***/ 7838:
/*!*************************************!*\
  !*** ./src/app/shop/shop.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShopPageModule": () => (/* binding */ ShopPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _shop_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./shop-routing.module */ 8098);
/* harmony import */ var _shop_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shop.page */ 900);







let ShopPageModule = class ShopPageModule {
};
ShopPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _shop_routing_module__WEBPACK_IMPORTED_MODULE_0__.ShopPageRoutingModule
        ],
        declarations: [_shop_page__WEBPACK_IMPORTED_MODULE_1__.ShopPage]
    })
], ShopPageModule);



/***/ }),

/***/ 900:
/*!***********************************!*\
  !*** ./src/app/shop/shop.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ShopPage": () => (/* binding */ ShopPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_shop_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./shop.page.html */ 5007);
/* harmony import */ var _shop_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shop.page.scss */ 447);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let ShopPage = class ShopPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['pay']);
    }
};
ShopPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ShopPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-shop',
        template: _raw_loader_shop_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_shop_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ShopPage);



/***/ }),

/***/ 447:
/*!*************************************!*\
  !*** ./src/app/shop/shop.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('contentshop.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  text-align: center;\n  font-family: Montserrat-SemiBold;\n  font-size: 18px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  color: white;\n  font-size: 18px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  justify-content: center;\n  text-align: center;\n  margin-top: 30px;\n}\n\n.list .btn {\n  --background: #36D3E1;\n  margin: 10px;\n  margin-top: 20px;\n  height: 35px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  background-color: white;\n  border-radius: 50%;\n  position: absolute;\n  right: 0;\n}\n\ninput[type=radio]:checked {\n  background-color: #DC3461;\n}\n\n.radio1 {\n  width: 0.8em;\n  height: 0.8em;\n}\n\n.btn1 {\n  --background: #DC3461;\n  height: 30px;\n  margin-top: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNob3AucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksb0VBQUE7QUFBSjs7QUFJRTtFQUNFLG9FQUFBO0VBRUEsK0JBQUE7RUFDQyxnQ0FBQTtBQUZMOztBQUlFO0VBQ0UseUJBQUE7RUFDQSxZQUFBO0VBQ0EsK0JBQUE7RUFDQyxnQ0FBQTtBQURMOztBQUdFO0VBQ0UsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtBQUFKOztBQUVJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBTjs7QUFFSTtFQUVFLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUROOztBQUdFO0VBQ0UscUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBREo7O0FBS0U7RUFDRSxhQUFBO0FBRko7O0FBSUU7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDRCxrQkFBQTtFQUNBLFFBQUE7QUFESDs7QUFHRTtFQUNFLHlCQUFBO0FBQUo7O0FBR0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUFKOztBQUVFO0VBQ0UscUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFDSiIsImZpbGUiOiJzaG9wLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL2NvbnRlbnRzaG9wLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgc2t5LnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcblxyXG4gICAgLnJvd3tcclxuICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgYmFja2dyb3VuZDojMzZEM0UxO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5yb3cxe1xyXG5cclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgfVxyXG4gIC5idG57XHJcbiAgICAtLWJhY2tncm91bmQ6ICMzNkQzRTE7XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gIH1cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgIHJpZ2h0OiAwO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2Vke1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0RDMzQ2MTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzF7XHJcbiAgICB3aWR0aDogMC44ZW07XHJcbiAgICBoZWlnaHQ6IDAuOGVtO1xyXG4gIH1cclxuICAuYnRuMXtcclxuICAgIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIG1hcmdpbi10b3A6IDYwcHg7XHJcbiAgfVxyXG5cclxuIl19 */");

/***/ }),

/***/ 5007:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shop/shop.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logoblue.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Compra de<img  src=\"../assets/began logo.svg\" alt=\"\"></ion-label>\n    </ion-row>\n    <ion-row class=\"row1\" style=\"font-size: 12px;\" >\n      <ion-label>la compare the tokens to perment deblaqure <br> progents picants de tu parja</ion-label>\n    </ion-row>\n    <ion-button  class=\"btn\" expand=\"full\"><img  src=\"../assets/began logo.svg\" alt=\"\">  1000\n      <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" /> </ion-button>\n    <ion-button  class=\"btn\" expand=\"full\">  2000<img  src=\"../assets/began logo.svg\" alt=\"\">  <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" /></ion-button>\n    <ion-button  class=\"btn\" expand=\"full\"><img  src=\"../assets/began logo.svg\" alt=\"\">  5000  <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" /></ion-button>\n\n      <ion-button class=\"btn1\" shape=\"round\" (click) = \"goto()\">PAGAR</ion-button>\n\n  </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_shop_shop_module_ts.js.map