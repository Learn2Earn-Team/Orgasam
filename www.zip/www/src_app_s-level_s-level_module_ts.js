(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_s-level_s-level_module_ts"],{

/***/ 7965:
/*!***************************************************!*\
  !*** ./src/app/s-level/s-level-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevelPageRoutingModule": () => (/* binding */ SLevelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _s_level_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level.page */ 9556);




const routes = [
    {
        path: '',
        component: _s_level_page__WEBPACK_IMPORTED_MODULE_0__.SLevelPage
    }
];
let SLevelPageRoutingModule = class SLevelPageRoutingModule {
};
SLevelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SLevelPageRoutingModule);



/***/ }),

/***/ 1072:
/*!*******************************************!*\
  !*** ./src/app/s-level/s-level.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevelPageModule": () => (/* binding */ SLevelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _s_level_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./s-level-routing.module */ 7965);
/* harmony import */ var _s_level_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level.page */ 9556);







let SLevelPageModule = class SLevelPageModule {
};
SLevelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _s_level_routing_module__WEBPACK_IMPORTED_MODULE_0__.SLevelPageRoutingModule
        ],
        declarations: [_s_level_page__WEBPACK_IMPORTED_MODULE_1__.SLevelPage]
    })
], SLevelPageModule);



/***/ }),

/***/ 9556:
/*!*****************************************!*\
  !*** ./src/app/s-level/s-level.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SLevelPage": () => (/* binding */ SLevelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_s_level_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./s-level.page.html */ 1953);
/* harmony import */ var _s_level_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./s-level.page.scss */ 8910);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let SLevelPage = class SLevelPage {
    constructor(router, alert) {
        this.router = router;
        this.alert = alert;
    }
    ngOnInit() {
    }
    alert1() {
        this.alert.simplealertred();
    }
    alert2() {
        this.alert.simplealertred1();
    }
    goto() {
        this.router.navigate(['s-level1']);
    }
};
SLevelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
SLevelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-s-level',
        template: _raw_loader_s_level_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_s_level_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SLevelPage);



/***/ }),

/***/ 8910:
/*!*******************************************!*\
  !*** ./src/app/s-level/s-level.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('yellow.jpg') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  color: white;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E9F673;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list2 {\n  margin-top: 10px;\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n}\n\n.list2 .row1 {\n  background: #E9F673;\n  padding: 5px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .row2 {\n  justify-content: center;\n  padding: 5px;\n  justify-content: center;\n  text-align: center;\n}\n\n.list2 .btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInMtbGV2ZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsZ0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSx1QkFBQTtFQUNBLGdDQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7RUFDRix1QkFBQTtBQUNBOztBQUFJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUVOOztBQUFJO0VBRUUsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtBQUNOOztBQUNJO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDRixxQkFBQTtBQUNKIiwiZmlsZSI6InMtbGV2ZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi8uLi8uLi9hc3NldHMveWVsbG93LmpwZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG5cclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG4ubGlzdDJ7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbmJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgLnJvdzF7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICAgIHBhZGRpbmc6IDVweDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5yb3cye1xyXG4gICAgICAvL2JhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAuYnRuIHtcclxuICAgICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICAgIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 1953:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/s-level/s-level.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logo2.svg\" alt=\"\">\n      </ion-list>\n\n      <ion-buttons slot=\"end\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Empieza a conocerme...</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/gmlevel.png\" alt=\"\">\n    </ion-row>\n    </ion-list>\n    <ion-list class=\"list2\">\n      <ion-row class=\"row1\" (click) = \"alert1()\">\n        Eres Visual, Auditiva, o Kinestésica (sensitiva)?\n      </ion-row>\n      <ion-row class=\"row2\" (click) = \"alert2()\">\n        Mantienes relaciones sexuales con frecuencia?\n      </ion-row>\n      <ion-row class=\"row1\" (click) = \"alert1()\">\n        Has probado a vendar tus ojos para poner a prueba el resto de los sentidos?\n      </ion-row>\n      <ion-row class=\"row2\" (click) = \"alert2()\">\n        Te gusta el sexo?\n      </ion-row>\n      <ion-row class=\"row1\" (click) = \"alert1()\">\n        Haces el amor con la luz apagada  o con la luz encendida?\n      </ion-row>\n      <ion-row class=\"row2\" (click) = \"alert2()\">\n        Has tenido un orgasmo?\n      </ion-row>\n      <ion-row class=\"row1\" (click) = \"alert1()\">\n        ¿Conoces bien tu cuerpo?\n      </ion-row>\n      <ion-row class=\"row2\" (click) = \"alert2()\">\n        Eres una persona Romántica, sensual o pasional?\n      </ion-row>\n      <ion-row class=\"row1\" (click) = \"alert1()\">\n        TE GUSTA LO QUE DESCUBRES, VAMOS AL NIVEL 2\n      </ion-row>\n      <ion-row class=\"row1\">\n        <ion-button class=\"btn\" shape=\"round\" (click) = \"goto()\">SABER MÁS!</ion-button>\n      </ion-row>\n    </ion-list>\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_s-level_s-level_module_ts.js.map