(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_blackcastle_blackcastle_module_ts"],{

/***/ 1975:
/*!***********************************************************!*\
  !*** ./src/app/blackcastle/blackcastle-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlackcastlePageRoutingModule": () => (/* binding */ BlackcastlePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _blackcastle_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./blackcastle.page */ 3935);




const routes = [
    {
        path: '',
        component: _blackcastle_page__WEBPACK_IMPORTED_MODULE_0__.BlackcastlePage
    }
];
let BlackcastlePageRoutingModule = class BlackcastlePageRoutingModule {
};
BlackcastlePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BlackcastlePageRoutingModule);



/***/ }),

/***/ 4569:
/*!***************************************************!*\
  !*** ./src/app/blackcastle/blackcastle.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlackcastlePageModule": () => (/* binding */ BlackcastlePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _blackcastle_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./blackcastle-routing.module */ 1975);
/* harmony import */ var _blackcastle_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./blackcastle.page */ 3935);







let BlackcastlePageModule = class BlackcastlePageModule {
};
BlackcastlePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _blackcastle_routing_module__WEBPACK_IMPORTED_MODULE_0__.BlackcastlePageRoutingModule
        ],
        declarations: [_blackcastle_page__WEBPACK_IMPORTED_MODULE_1__.BlackcastlePage]
    })
], BlackcastlePageModule);



/***/ }),

/***/ 3935:
/*!*************************************************!*\
  !*** ./src/app/blackcastle/blackcastle.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlackcastlePage": () => (/* binding */ BlackcastlePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_blackcastle_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./blackcastle.page.html */ 7337);
/* harmony import */ var _blackcastle_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./blackcastle.page.scss */ 7621);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let BlackcastlePage = class BlackcastlePage {
    constructor() { }
    ngOnInit() {
    }
};
BlackcastlePage.ctorParameters = () => [];
BlackcastlePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-blackcastle',
        template: _raw_loader_blackcastle_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_blackcastle_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], BlackcastlePage);



/***/ }),

/***/ 7621:
/*!***************************************************!*\
  !*** ./src/app/blackcastle/blackcastle.page.scss ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: #353030;\n}\n\nion-header {\n  background: #fff url('headerblack.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  color: white;\n  text-align: center;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n  font-size: 12px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #E10C46;\n  height: 35px;\n  font-size: 22px;\n  color: white;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .roww {\n  color: white;\n  background: #E10C46;\n  height: 35px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #616060;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: white;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E10C46;\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.row4 {\n  background: #E10C46;\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n  margin-top: -5px;\n}\n\n.row5 {\n  height: 40px;\n  background: #E10C46;\n  align-items: center;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.row6 {\n  height: 40px;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.row7 {\n  margin-top: 10px;\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.row8 {\n  background: #E10C46;\n  justify-content: center;\n  font-size: 13px;\n}\n\n.row9 {\n  text-align: center;\n  justify-content: center;\n  font-size: 13px;\n  margin-top: -5px;\n}\n\n.img1 {\n  position: absolute;\n  right: 0.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJsYWNrY2FzdGxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLHFCQUFBO0FBQUo7O0FBSUU7RUFDRSxxRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUVJO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBTjs7QUFFSTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBQU47O0FBRUk7RUFFRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRk47O0FBUUU7RUFDRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UsdUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBSEo7O0FBTUU7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFFQSxtQkFBQTtFQUVBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBTEo7O0FBT0U7RUFDRSxZQUFBO0VBRUEsdUJBQUE7RUFDQSxlQUFBO0FBTEo7O0FBT0U7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBSko7O0FBU0U7RUFDRSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFFO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQU5KOztBQVFFO0VBQ0Usa0JBQUE7RUFFQSxhQUFBO0FBTkoiLCJmaWxlIjoiYmxhY2tjYXN0bGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogIzM1MzAzMDtcclxuICBcclxuICBcclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyYmxhY2sucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuICBcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIC5saXN0e1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICBcclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNFMTBDNDY7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvd3d7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgYmFja2dyb3VuZDogI0UxMEM0NjtcclxuICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5yb3cxe1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuICBcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4gICAgLmxhYmx7XHJcbiAgXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuICBcclxuICAgIH1cclxuICBcclxuICBcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10gKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDk3LCA5NiwgOTYpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luOiAwIDAuNWVtO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgXHJcbiAgLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcbiAgXHJcbiAgLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcbiAgXHJcbiAgLnJhZGlvMyArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcbiAgXHJcbiAgLnJvdzN7XHJcbiAgICBtYXJnaW4tdG9wOiA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTEwQzQ2O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgXHJcbiAgfVxyXG4gIC5yb3c0e1xyXG4gICAgYmFja2dyb3VuZDogI0UxMEM0NjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuICBcclxuICB9XHJcbiAgLnJvdzV7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgXHJcbiAgICBiYWNrZ3JvdW5kOiAjRTEwQzQ2O1xyXG4gIFxyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gIH1cclxuICAucm93NntcclxuICAgIGhlaWdodDogNDBweDtcclxuICBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gIH1cclxuICAucm93N3tcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICBcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLnJvdzh7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTEwQzQ2O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgfVxyXG4gIC5yb3c5e1xyXG4gIFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gIH1cclxuICAuaW1nMXtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBcclxuICAgIHJpZ2h0OiAgMC41cmVtO1xyXG4gIH1cclxuICAiXX0= */");

/***/ }),

/***/ 7337:
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blackcastle/blackcastle.page.html ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logored.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons  slot=\"end\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>BLACK CASTTLE</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/blackcastell.png\" alt=\"\">\n    </ion-row>\n    <ion-row class=\"roww\" >\n      <ion-label>Preguntas picantes!</ion-label>\n    </ion-row>\n    <ion-row style=\"margin-top: 25px; margin-bottom: 5px;\" class=\"row1\" >\n      <ion-label  >Te gusta tener sexo en lugares públicos?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row9\">\n      <label for=\"br4\">SI</label>\n      <input id=\"br4\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n      <label for=\"br5\">NO</label>\n      <input id=\"br5\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n      <label for=\"br5\"></label>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Estarías dispuesta a hacer un trio?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"bq4\">SI</label>\n        <input id=\"bq4\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"bq5\">NO</label>\n        <input id=\"bq5\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"bq5\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Te gusta el BDSM? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"be4\">SI</label>\n        <input id=\"be4\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"be5\">NO</label>\n        <input id=\"be5\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"be5\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gustaría que te azotaran con un látigo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"bt4\">SI</label>\n        <input id=\"bt4\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"bt5\">NO</label>\n        <input id=\"bt5\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"bt5\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Estarías dispuesta a tener sexo con alguien de tu mismo sexo</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"by4\">SI</label>\n        <input id=\"by4\" type=\"radio\" name=\"group9\" class=\"radio1\" />\n        <label for=\"by5\">NO</label>\n        <input id=\"by5\" type=\"radio\" name=\"group9\" class=\"radio2\" />\n        <label for=\"by5\"></label>\n        <img   class=\"img1\" src=\"../../assets/play.svg\" alt=\"\">\n\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gusta el sexo anal?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"ba4\">SI</label>\n        <input id=\"ba4\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"ba5\">NO</label>\n        <input id=\"ba5\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"ba5\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Irías a clubes de intercambio?</ion-label>\n\n    </ion-row>\n\n    <ion-row  class=\"row2\"   >\n      <ion-col >\n        <label for=\"bs4\">SI</label>\n        <input id=\"bs4\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"bs5\">NO</label>\n        <input id=\"bs5\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"bs5\"></label>\n      </ion-col>\n\n    </ion-row>\n\n\n\n  </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_blackcastle_blackcastle_module_ts.js.map