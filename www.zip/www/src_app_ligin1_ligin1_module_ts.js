(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_ligin1_ligin1_module_ts"],{

/***/ 2477:
/*!*************************************************!*\
  !*** ./src/app/ligin1/ligin1-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ligin1PageRoutingModule": () => (/* binding */ Ligin1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ligin1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ligin1.page */ 3340);




const routes = [
    {
        path: '',
        component: _ligin1_page__WEBPACK_IMPORTED_MODULE_0__.Ligin1Page
    }
];
let Ligin1PageRoutingModule = class Ligin1PageRoutingModule {
};
Ligin1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], Ligin1PageRoutingModule);



/***/ }),

/***/ 6111:
/*!*****************************************!*\
  !*** ./src/app/ligin1/ligin1.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ligin1PageModule": () => (/* binding */ Ligin1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _ligin1_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ligin1-routing.module */ 2477);
/* harmony import */ var _ligin1_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ligin1.page */ 3340);







let Ligin1PageModule = class Ligin1PageModule {
};
Ligin1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ligin1_routing_module__WEBPACK_IMPORTED_MODULE_0__.Ligin1PageRoutingModule
        ],
        declarations: [_ligin1_page__WEBPACK_IMPORTED_MODULE_1__.Ligin1Page]
    })
], Ligin1PageModule);



/***/ }),

/***/ 3340:
/*!***************************************!*\
  !*** ./src/app/ligin1/ligin1.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ligin1Page": () => (/* binding */ Ligin1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_ligin1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./ligin1.page.html */ 2690);
/* harmony import */ var _ligin1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ligin1.page.scss */ 999);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let Ligin1Page = class Ligin1Page {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['login']);
    }
};
Ligin1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
Ligin1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ligin1',
        template: _raw_loader_ligin1_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_ligin1_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Ligin1Page);



/***/ }),

/***/ 999:
/*!*****************************************!*\
  !*** ./src/app/ligin1/ligin1.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@charset \"UTF-8\";\nion-content {\n  --background: #fff url('iPhone 6, 7, 8 – 1.png') no-repeat center center / cover;\n}\n.feel {\n  font-size: 20px;\n  color: white;\n  font-weight: bold;\n  font-family: Segoe UI;\n  margin-top: 60%;\n  text-align: center;\n}\n.logo {\n  text-align: center;\n  background: transparent;\n  margin-top: 60%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpZ2luMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FBQWhCO0VBRUUsZ0ZBQUE7QUFDRjtBQUNBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRUY7QUFDQTtFQUNBLGtCQUFBO0VBQ0UsdUJBQUE7RUFDQSxlQUFBO0FBRUYiLCJmaWxlIjoibGlnaW4xLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9pUGhvbmUgNiwgNywgOCDigJMgMS5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG59XHJcbi5mZWVse1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1mYW1pbHk6IFNlZ29lIFVJO1xyXG4gIG1hcmdpbi10b3A6IDYwJTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5sb2dve1xyXG50ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgbWFyZ2luLXRvcDogNjAlO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 2690:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ligin1/ligin1.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content (click) = \"goto()\">\n<p class=\"feel\">\n  FEEL YOUR BODY\n</p>\n  <ion-list class = \"logo\">\n    <img  src=\"assets/logo.svg\">\n  </ion-list>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_ligin1_ligin1_module_ts.js.map