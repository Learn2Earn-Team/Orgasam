(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_pay_pay_module_ts"],{

/***/ 2737:
/*!*******************************************!*\
  !*** ./src/app/pay/pay-routing.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayPageRoutingModule": () => (/* binding */ PayPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _pay_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pay.page */ 8941);




const routes = [
    {
        path: '',
        component: _pay_page__WEBPACK_IMPORTED_MODULE_0__.PayPage
    }
];
let PayPageRoutingModule = class PayPageRoutingModule {
};
PayPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PayPageRoutingModule);



/***/ }),

/***/ 9485:
/*!***********************************!*\
  !*** ./src/app/pay/pay.module.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayPageModule": () => (/* binding */ PayPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _pay_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pay-routing.module */ 2737);
/* harmony import */ var _pay_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pay.page */ 8941);







let PayPageModule = class PayPageModule {
};
PayPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pay_routing_module__WEBPACK_IMPORTED_MODULE_0__.PayPageRoutingModule
        ],
        declarations: [_pay_page__WEBPACK_IMPORTED_MODULE_1__.PayPage]
    })
], PayPageModule);



/***/ }),

/***/ 8941:
/*!*********************************!*\
  !*** ./src/app/pay/pay.page.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PayPage": () => (/* binding */ PayPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_pay_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./pay.page.html */ 7068);
/* harmony import */ var _pay_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pay.page.scss */ 5013);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let PayPage = class PayPage {
    constructor() { }
    ngOnInit() {
    }
};
PayPage.ctorParameters = () => [];
PayPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-pay',
        template: _raw_loader_pay_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pay_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PayPage);



/***/ }),

/***/ 5013:
/*!***********************************!*\
  !*** ./src/app/pay/pay.page.scss ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header sky.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  text-align: center;\n  font-family: Montserrat-SemiBold;\n  font-size: 18px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #36D3E1;\n  height: 35px;\n  color: white;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .btn {\n  --background: #DC3461;\n  height: 35px;\n}\n\nion-input {\n  background: white;\n  height: 20px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 9px 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.btn1 {\n  --background: #DC3461;\n  height: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBheS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSwrREFBQTtBQUFKOztBQUlFO0VBQ0Usb0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBRkw7O0FBSUU7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQU47O0FBR0U7RUFDRSxxQkFBQTtFQUVBLFlBQUE7QUFGSjs7QUErQkU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7QUE1Qko7O0FBbUNBO0VBQ0UsYUFBQTtBQWhDRjs7QUFrQ0E7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUEvQkY7O0FBaUNBO0VBQ0UseUJBQUE7QUE5QkY7O0FBaUNBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUE5QkY7O0FBaUNBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUE5QkY7O0FBaUNBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUE5QkY7O0FBaUNBO0VBQ0UscUJBQUE7RUFFQSxZQUFBO0FBL0JGIiwiZmlsZSI6InBheS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcblxyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4uLy4uL2Fzc2V0cy9oZWFkZXJcXCBza3kucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiMzNkQzRTE7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuXHJcbiAgLmJ0bntcclxuICAgIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgfVxyXG5cclxuICB9XHJcbiAgLy9pbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgLy8gIGRpc3BsYXk6IG5vbmU7XHJcbiAgLy99XHJcbiAgLy9pbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgLy8gIGNvbnRlbnQ6ICcnO1xyXG4gIC8vICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgLy8gIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgLy8gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIC8vICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgLy9cclxuICAvL31cclxuICAvL2lucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQgICsgaW1nOjpiZWZvcmV7XHJcbiAgLy8gIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbiAgLy99XHJcbiAgLy9cclxuICAvLy5yYWRpbzEgKyBpbWc6OmJlZm9yZXtcclxuICAvLyAgd2lkdGg6IDAuOGVtO1xyXG4gIC8vICBoZWlnaHQ6IDAuOGVtO1xyXG4gIC8vfVxyXG4gIC8vLmJ0bjEgKyBpbWc6OmJlZm9yZXtcclxuICAvLyAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG4gIC8vICBoZWlnaHQ6IDMwcHg7XHJcbiAgLy9cclxuICAvL31cclxuICAvL1xyXG4gIGlvbi1pbnB1dHtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG5cclxuICB9XHJcblxyXG5cclxuXHJcblxyXG5pbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgZGlzcGxheTogbm9uZTtcclxufVxyXG5pbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gIGNvbnRlbnQ6ICcnO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBtYXJnaW46IDlweCAwLjVlbTtcclxufVxyXG5pbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0RDMzQ2MTtcclxufVxyXG5cclxuLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gIHdpZHRoOiAwLjVlbTtcclxuICBoZWlnaHQ6IDAuNWVtO1xyXG59XHJcblxyXG4ucmFkaW8yICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgd2lkdGg6IDAuNWVtO1xyXG4gIGhlaWdodDogMC41ZW07XHJcbn1cclxuXHJcbi5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICB3aWR0aDogMC41ZW07XHJcbiAgaGVpZ2h0OiAwLjVlbTtcclxufVxyXG5cclxuLmJ0bjF7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG5cclxuICBoZWlnaHQ6IDM1cHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 7068:
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pay/pay.page.html ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logoblue.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>PAGO</ion-label>\n    </ion-row>\n\n    <ion-button  class=\"btn\" style=\"margin-top: 20px;\" expand=\"full\"> <img  src=\"../assets/began logo.svg\" alt=\"\">  1000 </ion-button>\n    <ion-button  class=\"btn\" style=\"margin-top: 10px;\" expand=\"full\">  TOTAL: 5€   </ion-button>\n\n  </ion-list>\n<!--  <ion-grid style=\"font-size: 15px;\">-->\n<!--    <ion-row>-->\n<!--      <ion-col size=\"2\" >-->\n<!--        <img  src=\"../../assets/visa.svg\" alt=\"\">-->\n\n<!--      </ion-col>-->\n<!--      <ion-col size=\"1\" style=\"margin-left: -13px; margin-top: 5px;\" >-->\n<!--        <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />-->\n<!--      </ion-col>-->\n<!--      <ion-col size=\"2\">-->\n<!--        <img  src=\"../../assets/mastercard.svg\" alt=\"\">-->\n<!--      </ion-col >-->\n<!--      <ion-col size=\"1\" style=\"margin-left: -13px; margin-top: 5px;\">-->\n<!--        <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />-->\n<!--      </ion-col>-->\n<!--    </ion-row>-->\n<!--  </ion-grid>-->\n  <ion-row class=\"row2\">\n    <ion-col >\n      <label for=\"r1\"><img  src=\"../../assets/visa.svg\" alt=\"\"></label>\n      <input id=\"r1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n      <label for=\"r2\"> <img  src=\"../../assets/mastercard.svg\" alt=\"\"></label>\n      <input id=\"r2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n      <label for=\"r2\"></label>\n    </ion-col>\n  </ion-row>\n  <ion-grid style=\"font-size: 15px;\">\n    <ion-row>\n      <ion-col size=\"5\" >\n        <ion-label>Numero de Tarteja:</ion-label>\n      </ion-col>\n      <ion-col size=\"1.5\" >\n        <ion-input></ion-input>\n      </ion-col>\n      <ion-col size=\"1.5\" >\n        <ion-input></ion-input>\n      </ion-col>\n      <ion-col size=\"1.5\">\n        <ion-input></ion-input>\n      </ion-col>\n      <ion-col size=\"1.5\">\n        <ion-input></ion-input>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid style=\"font-size: 15px;\">\n    <ion-row>\n      <ion-col size=\"2.5\" >\n        <ion-label>Numero:</ion-label>\n      </ion-col>\n      <ion-col size=\"8.5\" >\n        <ion-input></ion-input>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid style=\"font-size: 15px;\">\n    <ion-row>\n      <ion-col size=\"7.5\" >\n        <ion-label>Fecha de caducidad:00/00/00 </ion-label>\n      </ion-col>\n      <ion-col size=\"0.5\" >\n      <ion-label style=\"color: #DC3461; font-weight: bold;\">|</ion-label>\n      </ion-col>\n      <ion-col size=\"1.5\">\n        <ion-label>CVV:</ion-label>\n      </ion-col>\n      <ion-col size=\"1.5\">\n        <ion-input></ion-input>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n\n  <ion-list class=\"list\">\n      <ion-button class=\"btn1\" shape=\"round\">PAGAR</ion-button>\n\n    </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pay_pay_module_ts.js.map