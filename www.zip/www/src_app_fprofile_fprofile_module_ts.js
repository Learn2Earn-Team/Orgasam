(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_fprofile_fprofile_module_ts"],{

/***/ 4519:
/*!*****************************************************!*\
  !*** ./src/app/fprofile/fprofile-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilePageRoutingModule": () => (/* binding */ FprofilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _fprofile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fprofile.page */ 8338);




const routes = [
    {
        path: '',
        component: _fprofile_page__WEBPACK_IMPORTED_MODULE_0__.FprofilePage
    }
];
let FprofilePageRoutingModule = class FprofilePageRoutingModule {
};
FprofilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FprofilePageRoutingModule);



/***/ }),

/***/ 6286:
/*!*********************************************!*\
  !*** ./src/app/fprofile/fprofile.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilePageModule": () => (/* binding */ FprofilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _fprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fprofile-routing.module */ 4519);
/* harmony import */ var _fprofile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fprofile.page */ 8338);







let FprofilePageModule = class FprofilePageModule {
};
FprofilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _fprofile_routing_module__WEBPACK_IMPORTED_MODULE_0__.FprofilePageRoutingModule
        ],
        declarations: [_fprofile_page__WEBPACK_IMPORTED_MODULE_1__.FprofilePage]
    })
], FprofilePageModule);



/***/ }),

/***/ 8338:
/*!*******************************************!*\
  !*** ./src/app/fprofile/fprofile.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilePage": () => (/* binding */ FprofilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_fprofile_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./fprofile.page.html */ 5733);
/* harmony import */ var _fprofile_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fprofile.page.scss */ 7448);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let FprofilePage = class FprofilePage {
    constructor(router) {
        this.router = router;
        this.sex = [{ name: 'Heterosexual', value: false }, { name: 'Bisexual', value: false }, { name: 'Gay', value: false }, { name: 'Lesbiana', value: false },];
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['mprofilelevel']);
    }
    goto1() {
        this.router.navigate(['fprofilelevel']);
    }
    click(target) {
        target.style = 'background: #DR5D7F';
    }
    select(i) {
        this.sex[i].value = true;
    }
};
FprofilePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
FprofilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-fprofile',
        template: _raw_loader_fprofile_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_fprofile_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FprofilePage);



/***/ }),

/***/ 7448:
/*!*********************************************!*\
  !*** ./src/app/fprofile/fprofile.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('header Pr.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E06082;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list2 {\n  background: transparent;\n  margin-left: 26px;\n  margin-right: 26px;\n  font-size: 13px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list2 .row1 {\n  margin-top: 22px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list2 .row2 {\n  margin-top: 10px;\n}\n\n.list2 .input1 {\n  background: #ECA4B4;\n  margin-top: 13px;\n}\n\n.list2 .list2_row4 {\n  height: 35px;\n  background: #ECA4B4;\n  margin-top: 19px;\n}\n\n.list2 .label1 {\n  font-size: 15px;\n}\n\n.list2 .row5_col {\n  padding: 0px;\n  height: 32px;\n  background: #DFB7C3;\n  font-size: 10px;\n  text-align: center;\n  margin-right: 5px;\n}\n\n.list2 .row5_col:checked {\n  background-color: #DD5D7F;\n  color: white;\n}\n\n.list3 {\n  background: transparent;\n  font-size: 13px;\n  font-family: Montserrat-SemiBold;\n}\n\n.list3 .row6 {\n  background-color: #E0CED5;\n  text-align: center;\n  justify-content: center;\n}\n\n.list3 .row7 {\n  background-color: #E0CED5;\n  text-align: center;\n  justify-content: center;\n}\n\n.list3 .row8 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list3 .row9 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list3 .btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.list3 .row10 {\n  margin-top: 15px;\n  justify-content: center;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\nbutton:focus {\n  background: #F94272;\n  color: white;\n}\n\nbutton {\n  width: 100%;\n  height: 32px;\n  background: transparent;\n}\n\n.coldesign {\n  padding: 0px;\n  height: 20px;\n}\n\n.button1:focus {\n  background: #F94272;\n  color: white;\n}\n\nbutton1 {\n  width: 100%;\n  height: 32px;\n  background: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZwcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0VBRUEsZ0NBQUE7QUFESjs7QUFHRTtFQUNFLG1FQUFBO0VBRUEsK0JBQUE7RUFDQyxnQ0FBQTtBQURMOztBQUdFO0VBQ0UseUJBQUE7RUFDQSxZQUFBO0VBQ0EsK0JBQUE7RUFDQyxnQ0FBQTtBQUFMOztBQUVFO0VBQ0UsdUJBQUE7QUFDSjs7QUFDSTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFDTjs7QUFFQTtFQUNJLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQ0FBQTtBQUNKOztBQUFJO0VBQ0ksZ0JBQUE7RUFFQSxnQ0FBQTtBQUNSOztBQUNJO0VBQ0ksZ0JBQUE7QUFDUjs7QUFDSTtFQUNJLG1CQUFBO0VBQ0EsZ0JBQUE7QUFDUjs7QUFDSTtFQUVJLFlBQUE7RUFDSixtQkFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBRUk7RUFFSSxlQUFBO0FBRFI7O0FBR0k7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFEUjs7QUFJSTtFQUVFLHlCQUFBO0VBQ0UsWUFBQTtBQUhSOztBQU1JO0VBQ0ksdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0NBQUE7QUFIUjs7QUFLUTtFQUVJLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBQUpaOztBQU1RO0VBRUkseUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBTFo7O0FBT1E7RUFFSSxrQkFBQTtFQUNBLHVCQUFBO0FBTlo7O0FBUVE7RUFHSSxrQkFBQTtFQUNBLHVCQUFBO0FBUlo7O0FBVVE7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBUlY7O0FBWVU7RUFDQyxnQkFBQTtFQUVDLHVCQUFBO0FBWFo7O0FBZUE7RUFDRSxhQUFBO0FBWkY7O0FBY0E7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQVhGOztBQWFBO0VBQ0UseUJBQUE7QUFWRjs7QUFhQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBVkY7O0FBYUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQVZGOztBQWFBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFWRjs7QUFhQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtBQVZGOztBQVlBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtBQVRGOztBQVdBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7QUFSRjs7QUFZQTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtBQVRGOztBQVdBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtBQVJGIiwiZmlsZSI6ImZwcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuL3NyYy9hc3NldHMvUmVjdGFuZ2xlIDE4NS5wbmdcIik7XHJcbiAgICAtLWJhY2tncm91bmQ6ICAgIHVybCgnLi4vLi4vYXNzZXRzL3NjcmVlbi5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gIH1cclxuICBpb24taGVhZGVye1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4vLi4vLi4vYXNzZXRzL2hlYWRlclxcIFByLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjRTA2MDgyO1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbn1cclxuLmxpc3Qye1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogMjZweDtcclxuICAgIG1hcmdpbi1yaWdodDogMjZweDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgLnJvdzF7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMjJweDtcclxuXHJcbiAgICAgICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgfVxyXG4gICAgLmlucHV0MXtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjRUNBNEI0O1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDEzcHg7XHJcbiAgICB9XHJcbiAgICAubGlzdDJfcm93NHtcclxuXHJcbiAgICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgYmFja2dyb3VuZDojRUNBNEI0O1xyXG4gICAgbWFyZ2luLXRvcDogMTlweDtcclxuICAgIH1cclxuICAgIC5sYWJlbDFcclxuICAgIHtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICB9XHJcbiAgICAucm93NV9jb2x7XHJcbiAgICAgIHBhZGRpbmc6IDBweDtcclxuICAgICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNERkI3QzM7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAgIH1cclxuXHJcbiAgICAucm93NV9jb2w6Y2hlY2tlZHtcclxuXHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNERDVEN0Y7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gICAgfVxyXG4gICAgLmxpc3Qze1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuXHJcbiAgICAgICAgLnJvdzZcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNFMENFRDU7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yb3c3XHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTBDRUQ1O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAucm93OFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJvdzlcclxuICAgICAgICB7XHJcblxyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuYnRuIHtcclxuICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgICAgICAtLWJhY2tncm91bmQ6ICNEQzM0NjE7XHJcblxyXG5cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5yb3cxMHtcclxuICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG5cclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgfVxyXG4gICAgfVxyXG5pbnB1dFt0eXBlPXJhZGlvXSB7XHJcbiAgZGlzcGxheTogbm9uZTtcclxufVxyXG5pbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gIGNvbnRlbnQ6ICcnO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBtYXJnaW46IDAgMC41ZW07XHJcbn1cclxuaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCArIGxhYmVsOjpiZWZvcmUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbn1cclxuXHJcbi5yYWRpbzEgKyBsYWJlbDo6YmVmb3JlIHtcclxuICB3aWR0aDogMC41ZW07XHJcbiAgaGVpZ2h0OiAwLjVlbTtcclxufVxyXG5cclxuLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gIHdpZHRoOiAwLjVlbTtcclxuICBoZWlnaHQ6IDAuNWVtO1xyXG59XHJcblxyXG4ucmFkaW8zICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgd2lkdGg6IDAuNWVtO1xyXG4gIGhlaWdodDogMC41ZW07XHJcbn1cclxuXHJcbmJ1dHRvbjpmb2N1c3tcclxuICBiYWNrZ3JvdW5kOiNGOTQyNzI7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcbmJ1dHRvbntcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDMycHg7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbn1cclxuLmNvbGRlc2lnbntcclxuICBwYWRkaW5nOiAwcHg7XHJcbiAgaGVpZ2h0OiAyMHB4O1xyXG59XHJcblxyXG5cclxuLmJ1dHRvbjE6Zm9jdXN7XHJcbiAgYmFja2dyb3VuZDojRjk0MjcyO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5idXR0b24xe1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMzJweDtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 5733:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/fprofile/fprofile.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n    <!-- <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\"> -->\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n    </ion-list>\n\n    <ion-list class=\"list2\">\n      <ion-row class=\"row1\">\n        <ion-label class=\"label1\">\n          Elige las fotos que quieren que vean de ti!\n        </ion-label>\n\n      </ion-row>\n      <ion-row class=\"row2\">\n        <ion-col>\n          <img src=\"./../../assets/prpic1.png\">\n        </ion-col>\n        <ion-col>\n          <img src=\"./../../assets/prpic2.png\">\n        </ion-col>\n        <ion-col>\n          <img src=\"./../../assets/prpoc.png\">\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-label style=\"text-decoration: underline;\">\n          Agregar mas fotos\n        </ion-label>\n      </ion-row>\n\n      <ion-row>\n        <ion-input class=\"input1\" placeholder = \"Nombre\" ></ion-input>\n      </ion-row>\n      <ion-row>\n        <ion-col size = \"5\">\n          <ion-input class=\"input1\" placeholder = \"Edad\" ></ion-input>\n        </ion-col>\n        <ion-col size = \"7\" class = \"list2_row4\">\n          <ion-label> SEXO </ion-label>\n          <label style=\"margin-left: 20px;\" for=\"prk1\">F</label>\n          <input style=\"margin-left: 10px;\"  id=\"prk1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n          <label style=\"margin-left: 10px;\"  for=\"prk2\">M</label>\n          <input style=\"margin-left: 10px;\"  id=\"prk2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n          <label style=\"margin-left: 10px;\"  for=\"prk2\"></label>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-label class=\"label1\">\n          Orientación Sexual\n        </ion-label>\n      </ion-row>\n      <ion-row>\n        <ion-col size = \"2.9\" class=\"row5_col\">\n          <button id=\"5\" name=\"group12\">Heterosel</button>\n        </ion-col>\n        <ion-col size = \"2.8\" class=\"row5_col\">\n          <button id=\"6\" name=\"group12\">Bisexual</button>\n\n        </ion-col>\n        <ion-col size = \"2.7\" class=\"row5_col\">\n          <button id=\"7\" name=\"group12\">Gay</button>\n\n        </ion-col>\n        <ion-col size = \"2.8\" class=\"row5_col\">\n          <button id=\"2\" name=\"group12\">Lesbiana</button>\n        </ion-col>\n      </ion-row>\n      <ion-row style=\"margin-top: 10px;\">\n        <ion-label class=\"label1\">\n          Situación Sentimental\n        </ion-label>\n      </ion-row>\n      <ion-row style=\"margin-top: 5px;\">\n        <ion-col  size = \"3\" class=\"row5_col\">\n          <button class=\"button1\" id=\"1\" name=\"group21\">En Pareja</button>\n\n        </ion-col>\n        <ion-col size = \"3\" class=\"row5_col\" (click) = \"goto()\">\n          <button class=\"button1\" id=\"2\" name=\"group21\">Soltero (a)</button>\n\n        </ion-col>\n        <ion-col size = \"4\" class=\"row5_col\">\n          <button class=\"button1\" id=\"3\" name=\"group21\"> Unión Libre</button>\n\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <hr style=\"background-color: #D0355B; width: 100%; height: 5px;  \" >\n      </ion-row>\n    </ion-list>\n\n    <ion-list class=\"list3\">\n      <ion-row  class=\"row6\" style=\"margin-top: 7px;\">\n       ¿Estás A gusto con tu pareja?\n      </ion-row>\n      <ion-row class=\"row7\">\n        <ion-col >\n          <label for=\"prq1\">SI</label>\n          <input id=\"prq1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n          <label for=\"prq2\">NO</label>\n          <input id=\"prq2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n          <label for=\"prq3\">NO LO SÉ</label>\n          <input id=\"prq3\" type=\"radio\" name=\"group2\" class=\"radio3\" />\n          <label for=\"prq3\"></label>\n        </ion-col>\n      </ion-row>\n      <ion-row  class=\"row8\" style=\"margin-top: 7px; background-color: none; \">\n        ¿Sueles hablar de tus deseos sexuales con tu pareja?\n       </ion-row>\n       <ion-row class=\"row9\" style=\"background-color:none;\">\n         <ion-col >\n           <label for=\"pre1\">SI</label>\n           <input id=\"pre1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n           <label for=\"pre2\">NO</label>\n           <input id=\"pre2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n           <label for=\"pre3\"> NO MUCHO</label>\n           <input id=\"pre3\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n           <label for=\"pre3\"></label>\n         </ion-col>\n       </ion-row>\n       <ion-row  class=\"row6\" style=\"margin-top: 7px;\">\n        ¿Mantienes relaciones sexuales con frecuencia?\n       </ion-row>\n       <ion-row class=\"row7\">\n         <ion-col >\n           <label for=\"prt1\">SI</label>\n           <input id=\"prt1\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n           <label for=\"prt2\">NO</label>\n           <input id=\"prt2\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n           <label for=\"prt3\">NO MUCHO</label>\n           <input id=\"prt3\" type=\"radio\" name=\"group7\" class=\"radio3\" />\n           <label for=\"prt3\"></label>\n         </ion-col>\n       </ion-row>\n       <ion-row class=\"row10\">\n\n        <ion-button class=\"btn\" shape=\"round\" (click)=\"goto1()\" >FINALIZAR</ion-button>\n      </ion-row>\n    </ion-list>\n\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_fprofile_fprofile_module_ts.js.map