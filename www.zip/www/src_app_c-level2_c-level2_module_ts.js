(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_c-level2_c-level2_module_ts"],{

/***/ 9593:
/*!*****************************************************!*\
  !*** ./src/app/c-level2/c-level2-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel2PageRoutingModule": () => (/* binding */ CLevel2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _c_level2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level2.page */ 2437);




const routes = [
    {
        path: '',
        component: _c_level2_page__WEBPACK_IMPORTED_MODULE_0__.CLevel2Page
    }
];
let CLevel2PageRoutingModule = class CLevel2PageRoutingModule {
};
CLevel2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CLevel2PageRoutingModule);



/***/ }),

/***/ 7114:
/*!*********************************************!*\
  !*** ./src/app/c-level2/c-level2.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel2PageModule": () => (/* binding */ CLevel2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _c_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level2-routing.module */ 9593);
/* harmony import */ var _c_level2_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level2.page */ 2437);







let CLevel2PageModule = class CLevel2PageModule {
};
CLevel2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c_level2_routing_module__WEBPACK_IMPORTED_MODULE_0__.CLevel2PageRoutingModule
        ],
        declarations: [_c_level2_page__WEBPACK_IMPORTED_MODULE_1__.CLevel2Page]
    })
], CLevel2PageModule);



/***/ }),

/***/ 2437:
/*!*******************************************!*\
  !*** ./src/app/c-level2/c-level2.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevel2Page": () => (/* binding */ CLevel2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_c_level2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./c-level2.page.html */ 910);
/* harmony import */ var _c_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level2.page.scss */ 8146);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let CLevel2Page = class CLevel2Page {
    constructor(router, alert1) {
        this.router = router;
        this.alert1 = alert1;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['c-level3']);
    }
};
CLevel2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
CLevel2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-c-level2',
        template: _raw_loader_c_level2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_c_level2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CLevel2Page);



/***/ }),

/***/ 8146:
/*!*********************************************!*\
  !*** ./src/app/c-level2/c-level2.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n}\n\nion-header {\n  background: #fff url('header pink.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 10px;\n  background: #CE0647;\n  height: 35px;\n  color: white;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\n.list .alert-wrapper {\n  --background: url('alert image.png') no-repeat center center / cover !important;\n  --border-radius:5px!important;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E3D3D5;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E3D3D5;\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  text-align: center;\n  justify-content: center;\n}\n\nion-input {\n  height: 20px;\n  background: white;\n}\n\n.iput {\n  width: 70px;\n}\n\n.iput1 {\n  margin-right: 50px;\n}\n\n.row12 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row13 {\n  margin-top: -5px;\n}\n\n.text1 {\n  padding-left: 50px;\n  padding-right: 50px;\n}\n\n.row15 {\n  margin-top: 7px;\n  text-align: center;\n  justify-content: center;\n}\n\n.row16 {\n  margin-top: -5px;\n  text-align: center;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImMtbGV2ZWwyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLCtEQUFBO0FBQUo7O0FBSUU7RUFDRSxxRUFBQTtFQUVBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFGTDs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLCtCQUFBO0VBQ0MsZ0NBQUE7QUFETDs7QUFHRTtFQUNFLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBQUo7O0FBRUk7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFOOztBQUVJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUFOOztBQUVJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBQU47O0FBRUk7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRE47O0FBSUk7RUFDRSwrRUFBQTtFQUNBLDZCQUFBO0FBRk47O0FBT0U7RUFFRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UseUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBSE47O0FBTUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBSEY7O0FBT0U7RUFDQyxnQkFBQTtFQUVBLGtCQUFBO0VBQ0EsdUJBQUE7QUFMSDs7QUFRRTtFQUNFLFlBQUE7RUFDQSxpQkFBQTtBQUxKOztBQU9FO0VBQ0UsV0FBQTtBQUpKOztBQVFFO0VBQ0Esa0JBQUE7QUFMRjs7QUFPRTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7QUFKSjs7QUFRRTtFQUdFLGdCQUFBO0FBUEo7O0FBV0U7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBUkY7O0FBV0U7RUFDRSxlQUFBO0VBRUEsa0JBQUE7RUFDQSx1QkFBQTtBQVRKOztBQWFFO0VBRUUsZ0JBQUE7RUFDQSxrQkFBQTtFQUNFLHVCQUFBO0FBWE4iLCJmaWxlIjoiYy1sZXZlbDIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG5cclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLi8uLi9hc3NldHMvaGVhZGVyXFwgcGluay5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG5cclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi10b29sYmFye1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDIwcHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIC5saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuXHJcbiAgICAucm93e1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjQ0UwNjQ3O1xyXG4gICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5yb3cxe1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzJ7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiAgICAubGFibHtcclxuXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuXHJcbiAgICB9XHJcbiAgICAuYWxlcnQtd3JhcHBlcntcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAgdXJsKCcuLi8uLi9hc3NldHMvYWxlcnRcXCBpbWFnZS5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyICFpbXBvcnRhbnQ7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czo1cHghaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuXHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMDAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luOiAwIDAuNWVtO1xyXG4gIH1cclxuICBpbnB1dFt0eXBlPXJhZGlvXTpjaGVja2VkICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjREMzNDYxO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMSArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzIgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8zICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJvdzN7XHJcbiAgICBtYXJnaW4tdG9wOiA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTNEM0Q1O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAucm93NHtcclxuICAgIGJhY2tncm91bmQ6ICNFM0QzRDU7XHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5idG4ge1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcblxyXG4gIH1cclxuICAucm93OHtcclxuICAgbWFyZ2luLXRvcDogMTVweDtcclxuXHJcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgfVxyXG5cclxuICBpb24taW5wdXQge1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZDpyZ2IoMjU1LCAyNTUsIDI1NSlcclxuICB9XHJcbiAgLmlwdXR7XHJcbiAgICB3aWR0aDogNzBweDtcclxuXHJcblxyXG4gIH1cclxuICAuaXB1dDF7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1MHB4O1xyXG4gIH1cclxuICAucm93MTJ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcblxyXG4gIH1cclxuICAucm93MTN7XHJcblxyXG5cclxuICAgIG1hcmdpbi10b3A6IC01cHg7XHJcblxyXG4gIH1cclxuXHJcbiAgLnRleHQxe1xyXG4gIHBhZGRpbmctbGVmdDogNTBweDtcclxuICBwYWRkaW5nLXJpZ2h0OiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnJvdzE1e1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcblxyXG4gIC5yb3cxNntcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB9XHJcblxyXG4iXX0= */");

/***/ }),

/***/ 910:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/c-level2/c-level2.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logored.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/logo/edit w.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/couple3.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Cuales son tus gustos en el sexo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" (click) = \"test()\" alt=\"\">\n        </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que es lo que más te gusta hacer en la cama?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" (click) = \"test()\" alt=\"\">\n        </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Cuál es tu postura sexual favorita?</ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"c2r1\">SI </label>\n        <input id=\"c2r1\" type=\"radio\" name=\"group331\" class=\"radio1\" />\n        <label for=\"c2r2\">NO</label>\n        <input id=\"c2r2\" type=\"radio\" name=\"group331\" class=\"radio2\" />\n        <label for=\"c2r3\"> NO MUCHO</label>\n        <input id=\"c2r3\" type=\"radio\" name=\"group331\" class=\"radio3\" />\n        <label for=\"c2r3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n\n\n\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gusta el sexo brusco o suave?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col  >\n        <label for=\"c2q1\">Sexo tranquilo</label>\n        <input id=\"c2q1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"c2q2\">Sexo brusco </label>\n        <input id=\"c2q2\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"c2q3\">Ambos</label>\n        <input id=\"c2q3\" type=\"radio\" name=\"group2\" class=\"radio3\" />\n        <label for=\"c2q3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Que cosas no te gustan en el sexo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n        </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Que cosas te gustarían hacer y nunca has hecho? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\" style=\"background-color: #E3D3D5;\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n        </ion-col>\n\n    </ion-row>\n\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Cuales son las posturas que más te gustan?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" (click) = \"test()\" alt=\"\">\n        </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label style=\"margin-left: 40px; margin-right: 40px;\" >Cuales son las posturas que no te gustan? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"c2a1\">SI</label>\n        <input id=\"c2a1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"c2a2\">NO</label>\n        <input id=\"c2a2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"c2a3\">NO MUCHO</label>\n        <input id=\"c2a3\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"c2a3\"></label>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/r apple.svg\" alt=\"\">\n      </ion-col>\n\n    </ion-row>\n\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Que es lo más importante para ti en la cama? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col  >\n        <ion-input class=\"iput\" type=\"input\"  ></ion-input>\n       </ion-col>\n       <ion-col>\n         <ion-input class=\"iput\"  ></ion-input>\n       </ion-col>\n        <ion-col>\n         <ion-input class=\"iput\"></ion-input>\n        </ion-col>\n        <ion-col>\n          <ion-input class=\"iput\"></ion-input>\n         </ion-col>\n        <ion-col>\n         <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" (click) = \"test()\" alt=\"\">\n        </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Cual es tu mayor fantasía sexo?  </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\" style=\"background-color: #E3D3D5;\">\n      <ion-col>\n\n        <div class=\"text1\">\n\n\n\n\n          <ion-input class=\"nput1\"    ></ion-input>\n\n        </div>\n\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n       </ion-col>\n\n    </ion-row>\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Que es lo que más te excita en el sexo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col>\n        <div class=\"text1\">\n          <ion-input class=\"nput1\"    ></ion-input>\n        </div>\n        <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/w apple.svg\" alt=\"\">\n       </ion-col>\n\n    </ion-row>\n\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click) = \"goto()\" >SIGUIENTE</ion-button>\n    </ion-row>\n\n  </ion-list>\n\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_c-level2_c-level2_module_ts.js.map