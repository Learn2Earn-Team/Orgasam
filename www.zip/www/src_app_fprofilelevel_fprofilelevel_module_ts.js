(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_fprofilelevel_fprofilelevel_module_ts"],{

/***/ 6144:
/*!***************************************************************!*\
  !*** ./src/app/fprofilelevel/fprofilelevel-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilelevelPageRoutingModule": () => (/* binding */ FprofilelevelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _fprofilelevel_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fprofilelevel.page */ 9447);




const routes = [
    {
        path: '',
        component: _fprofilelevel_page__WEBPACK_IMPORTED_MODULE_0__.FprofilelevelPage
    }
];
let FprofilelevelPageRoutingModule = class FprofilelevelPageRoutingModule {
};
FprofilelevelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FprofilelevelPageRoutingModule);



/***/ }),

/***/ 3345:
/*!*******************************************************!*\
  !*** ./src/app/fprofilelevel/fprofilelevel.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilelevelPageModule": () => (/* binding */ FprofilelevelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _fprofilelevel_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fprofilelevel-routing.module */ 6144);
/* harmony import */ var _fprofilelevel_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fprofilelevel.page */ 9447);







let FprofilelevelPageModule = class FprofilelevelPageModule {
};
FprofilelevelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _fprofilelevel_routing_module__WEBPACK_IMPORTED_MODULE_0__.FprofilelevelPageRoutingModule
        ],
        declarations: [_fprofilelevel_page__WEBPACK_IMPORTED_MODULE_1__.FprofilelevelPage]
    })
], FprofilelevelPageModule);



/***/ }),

/***/ 9447:
/*!*****************************************************!*\
  !*** ./src/app/fprofilelevel/fprofilelevel.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FprofilelevelPage": () => (/* binding */ FprofilelevelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_fprofilelevel_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./fprofilelevel.page.html */ 5099);
/* harmony import */ var _fprofilelevel_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fprofilelevel.page.scss */ 9275);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let FprofilelevelPage = class FprofilelevelPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['f-level']);
    }
    goto1() {
        this.router.navigate(['f-level1']);
    }
    goto3() {
        this.router.navigate(['f-level2']);
    }
    goto4() {
        this.router.navigate(['f-level3']);
    }
    goto5() {
        this.router.navigate(['blackcastle']);
    }
    gotosearch() {
        this.router.navigate(['searchprofile']);
    }
};
FprofilelevelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
FprofilelevelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-fprofilelevel',
        template: _raw_loader_fprofilelevel_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_fprofilelevel_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FprofilelevelPage);



/***/ }),

/***/ 9275:
/*!*******************************************************!*\
  !*** ./src/app/fprofilelevel/fprofilelevel.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('header Pr.png') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list1 {\n  background: transparent;\n  height: 28%;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n  color: #DC3461;\n}\n\n.list1 .row1 {\n  justify-content: center;\n}\n\n.list1 .avatar3 {\n  height: 100px;\n  width: 100px;\n  margin-top: 10px;\n}\n\n.list1 .row2 {\n  justify-content: center;\n}\n\n.list3 {\n  background: #DE5C7C;\n  padding: 9px;\n  margin-top: 10px;\n}\n\n.list3 .row1 {\n  justify-content: center;\n}\n\n.list3 .row1 .input1 {\n  margin-left: 5px;\n  width: 270px;\n  border-radius: 17px;\n  height: 32px;\n  border-color: transparent;\n}\n\n.list4 {\n  background: #fff url('girllevel.png') no-repeat center center/cover;\n  height: 400px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZwcm9maWxlbGV2ZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsbUVBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBR0U7RUFDSSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBQU47O0FBQ007RUFDSSx1QkFBQTtBQUNWOztBQUNNO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUNWOztBQUNNO0VBQ0UsdUJBQUE7QUFDUjs7QUFFRTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQUk7RUFDSSx1QkFBQTtBQUVSOztBQURRO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFHWjs7QUFDQTtFQUNJLG1FQUFBO0VBQ0EsYUFBQTtBQUVKIiwiZmlsZSI6ImZwcm9maWxlbGV2ZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi8uLi8uLi9hc3NldHMvaGVhZGVyXFwgUHIucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgLmxpc3Qxe1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaGVpZ2h0OiAyOCU7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGNvbG9yOiAjREMzNDYxO1xyXG4gICAgICAucm93MXtcclxuICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICB9XHJcbiAgICAgIC5hdmF0YXIze1xyXG4gICAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICAgIHdpZHRoOiAxMDBweDtcclxuICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIH1cclxuICAgICAgLnJvdzJ7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIH1cclxuICB9XHJcbiAgLmxpc3Qze1xyXG4gICAgYmFja2dyb3VuZDogI0RFNUM3QztcclxuICAgIHBhZGRpbmc6IDlweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAucm93MXtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAuaW5wdXQxe1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgICAgICAgICB3aWR0aDogMjcwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE3cHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzJweDtcclxuICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuLmxpc3Q0e1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZiB1cmwoJy4vLi4vLi4vYXNzZXRzL2xldmVsL2dpcmxsZXZlbC5wbmcnKSBuby1yZXBlYXQgY2VudGVyIGNlbnRlciAvIGNvdmVyO1xyXG4gICAgaGVpZ2h0OiA0MDBweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ 5099:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/fprofilelevel/fprofilelevel.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n\n      <img  src=\"../../assets/logo/logo1.svg\" style=\"    margin-left: 25%;margin-top: 3%; \" alt=\"\">\n      <ion-buttons slot=\"end\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n    </ion-toolbar>\n    <!-- <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\"> -->\n  </ion-header>\n  <ion-list class=\"list1\">\n    <ion-row class=\"row1\">\n      <ion-avatar class=\"avatar3\">\n        <img  src=\"../../assets/prpic2.png\">\n      </ion-avatar>\n      <img src=\"../../assets/edit.svg\" style=\"margin-top: -55px;\">\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-label style=\"color: #2D3032;\">\n        SARA RODRÍGUEZ SOTO\n      </ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-label>\n        SOLTERA / HETEROSEXUAL\n      </ion-label>\n    </ion-row>\n    <ion-row class=\"row2\">\n      31 AÑOS\n    </ion-row>\n  </ion-list>\n  <ion-list class=\"list3\">\n    <ion-row class=\"row1\">\n      <img class=\"logo1\" src=\"./../../assets/search.svg\">\n      <input type=\"text\" class=\"input1\" (click)=\"gotosearch()\"/>\n    </ion-row>\n\n  </ion-list>\n\n  <ion-list class=\"list4\">\n    <img src=\"./assets/level/fstart.svg\" style=\"position: absolute;\" (click)=\"goto()\">\n    <img src=\"./assets/level/flevel2.svg\" style=\"    position: absolute;\n  top: 30%;\n    right: 33%;\" (click)=\"goto1()\">\n    <img src=\"./assets/level/flevel3.svg\" style=\"position: absolute;\n    /* left: 37px; */\n    top: 33px;\n    right: 0px;\" (click)=\"goto3()\">\n    <img src=\"./assets/level/fend.svg\" style=\"\n        position: absolute;\n        bottom: -31px;\n        left: -41px;\" (click)=\"goto4()\">\n    <img src=\"./assets/level/fblackcastel.svg \" style=\"position: absolute; bottom: 0px; right: -38px;\" (click)=\"goto5()\">\n  </ion-list>\n\n  </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_fprofilelevel_fprofilelevel_module_ts.js.map