(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_f-level_f-level_module_ts"],{

/***/ 7776:
/*!***************************************************!*\
  !*** ./src/app/f-level/f-level-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevelPageRoutingModule": () => (/* binding */ FLevelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _f_level_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./f-level.page */ 3770);




const routes = [
    {
        path: '',
        component: _f_level_page__WEBPACK_IMPORTED_MODULE_0__.FLevelPage
    }
];
let FLevelPageRoutingModule = class FLevelPageRoutingModule {
};
FLevelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FLevelPageRoutingModule);



/***/ }),

/***/ 4093:
/*!*******************************************!*\
  !*** ./src/app/f-level/f-level.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevelPageModule": () => (/* binding */ FLevelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _f_level_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./f-level-routing.module */ 7776);
/* harmony import */ var _f_level_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./f-level.page */ 3770);







let FLevelPageModule = class FLevelPageModule {
};
FLevelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _f_level_routing_module__WEBPACK_IMPORTED_MODULE_0__.FLevelPageRoutingModule
        ],
        declarations: [_f_level_page__WEBPACK_IMPORTED_MODULE_1__.FLevelPage]
    })
], FLevelPageModule);



/***/ }),

/***/ 3770:
/*!*****************************************!*\
  !*** ./src/app/f-level/f-level.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FLevelPage": () => (/* binding */ FLevelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_f_level_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./f-level.page.html */ 4507);
/* harmony import */ var _f_level_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./f-level.page.scss */ 1143);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let FLevelPage = class FLevelPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    profile() {
        this.router.navigate(['fprofile']);
    }
    level2() {
        this.router.navigate(['f-level1']);
    }
};
FLevelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
FLevelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-f-level',
        template: _raw_loader_f_level_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_f_level_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], FLevelPage);



/***/ }),

/***/ 1143:
/*!*******************************************!*\
  !*** ./src/app/f-level/f-level.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('yellow.jpg') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E9F673;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImYtbGV2ZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsZ0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSxlQUFBO0VBQ0EsZ0NBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUNJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUNOOztBQUNJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUVBLGdCQUFBO0FBRE47O0FBR0k7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRk47O0FBUUU7RUFDRSxhQUFBO0FBTEo7O0FBT0U7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUpKOztBQU1FO0VBQ0UseUJBQUE7QUFISjs7QUFNRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUhKOztBQU1FO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFISjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFISjs7QUFNRTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBSEo7O0FBTUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBSEY7O0FBT0U7RUFDQyxnQkFBQTtFQUVDLHVCQUFBO0FBTEoiLCJmaWxlIjoiZi1sZXZlbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLy4uLy4uL2Fzc2V0cy95ZWxsb3cuanBnJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIGZvbnQtZmFtaWx5OiBNb250c2VycmF0LVNlbWlCb2xkO1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgLnJvd3tcclxuICAgICAgbWFyZ2luLXRvcDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI0U5RjY3MztcclxuICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4gICAgLmxhYmx7XHJcblxyXG4gICAgICBtYXJnaW4tbGVmdDogMy41cHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogMy41cHg7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXJnaW46IDAgMC41ZW07XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbiAgfVxyXG5cclxuICAucmFkaW8xICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucm93M3tcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxuICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4gIC5yb3c0e1xyXG4gICAgYmFja2dyb3VuZDogI0U5RjY3MztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogLTVweDtcclxuXHJcbiAgfVxyXG4gIC5idG4ge1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gIC0tYmFja2dyb3VuZDogI0RDMzQ2MTtcclxuXHJcblxyXG4gIH1cclxuICAucm93OHtcclxuICAgbWFyZ2luLXRvcDogMTVweDtcclxuXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgfVxyXG4iXX0= */");

/***/ }),

/***/ 4507:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/f-level/f-level.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-buttons  slot=\"end\" style = \"margin-top: -18px;\">\n        <ion-menu-button color = \"light\"></ion-menu-button>\n      </ion-buttons>\n\n      <ion-list style=\"text-align: center;background: transparent;\">\n      <img  src=\"../../assets/logo/logo2.svg\" alt=\"\">\n      </ion-list>\n      <img style=\"position: absolute;bottom: -10px; right: 0; margin: 10px;\"  src=\"../../assets/inbox.svg\" alt=\"\" (click)=\"profile()\">\n    </ion-toolbar>\n\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/Group 377.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >Has probado a vendar tus ojos para poner a prueba el resto de los sentidos? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"fr1\">SI</label>\n        <input id=\"fr1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n        <label for=\"fr2\">NO</label>\n        <input id=\"fr2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n        <label for=\"fr3\">NO LO SÉ</label>\n        <input id=\"fr3\" type=\"radio\" name=\"group1\" class=\"radio3\" />\n        <label for=\"fr3\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Sueles hablar de sexo con tu circulo cercano? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"fl1\">SI</label>\n        <input id=\"fl1\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"fl3\">NO</label>\n        <input id=\"fl3\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"fl3\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Sueles hablar de deseos sexuales con tus parejas?   </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"fm1\">SI</label>\n        <input id=\"fm1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"fm2\">NO</label>\n        <input id=\"fm2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"fm2\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Cuanto Te gusta el sexo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"fj1\">normal</label>\n        <input id=\"fj1\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"fj2\">mucho Norma</label>\n        <input id=\"fj2\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"fj3\">MUCHO</label>\n        <input id=\"fj3\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"fj3\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >\tTe gusta hacer el amor con la luz apagada  o con la luz encendida? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"fh1\">Auditiva</label>\n        <input id=\"fh1\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"fh2\">Visual</label>\n        <input id=\"fh2\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"fh2\">Sensitiva</label>\n        <input id=\"fh3\" type=\"radio\" name=\"group5\" class=\"radio3\" />\n        <label for=\"fh3\"></label>\n\n\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Conoces bien tu cuerpo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"fq1\">SI</label>\n        <input id=\"fq1\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"fq2\">NO</label>\n        <input id=\"fq2\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"fq2\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Has probado a vendar tus ojos para poner a prueba el resto de los sentidos?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"fw1\">SI</label>\n        <input id=\"fw1\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"fw2\">NO</label>\n        <input id=\"fw2\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"fw2\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Eres una persona Romántica, sensual o pasional?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"fe1\">ROMANTICA</label>\n        <input id=\"fe1\" type=\"radio\" name=\"group8\" class=\"radio1\" />\n        <label for=\"fe2\">SENSUAL </label>\n        <input id=\"fe2\" type=\"radio\" name=\"group8\" class=\"radio2\" />\n        <label for=\"fe3\">PASIONAL</label>\n        <input id=\"fe3\" type=\"radio\" name=\"group8\" class=\"radio3\" />\n        <label for=\"fe3\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Eres mas de hacer el amor?  O el Sexo desenfrenado? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"ft1\">Hacer el amor</label>\n        <input id=\"ft1\" type=\"radio\" name=\"group9\" class=\"radio1\" />\n        <label for=\"ft2\">Sexo desenfrenado </label>\n        <input id=\"ft2\" type=\"radio\" name=\"group9\" class=\"radio2\" />\n        <label for=\"ft2\"></label>\n      </ion-col>\n    </ion-row>\n\n  </ion-list>\n  <ion-list class=\"list1\">\n\n  <ion-row class=\"row8\">\n\n    <ion-button class=\"btn\" shape=\"round\" (click)=\"level2()\">FINALIZAR</ion-button>\n  </ion-row>\n  </ion-list>\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_f-level_f-level_module_ts.js.map