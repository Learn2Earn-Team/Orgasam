(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_m-level_m-level_module_ts"],{

/***/ 6526:
/*!***************************************************!*\
  !*** ./src/app/m-level/m-level-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevelPageRoutingModule": () => (/* binding */ MLevelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _m_level_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level.page */ 5670);




const routes = [
    {
        path: '',
        component: _m_level_page__WEBPACK_IMPORTED_MODULE_0__.MLevelPage
    }
];
let MLevelPageRoutingModule = class MLevelPageRoutingModule {
};
MLevelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MLevelPageRoutingModule);



/***/ }),

/***/ 7003:
/*!*******************************************!*\
  !*** ./src/app/m-level/m-level.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevelPageModule": () => (/* binding */ MLevelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _m_level_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./m-level-routing.module */ 6526);
/* harmony import */ var _m_level_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level.page */ 5670);







let MLevelPageModule = class MLevelPageModule {
};
MLevelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _m_level_routing_module__WEBPACK_IMPORTED_MODULE_0__.MLevelPageRoutingModule
        ],
        declarations: [_m_level_page__WEBPACK_IMPORTED_MODULE_1__.MLevelPage]
    })
], MLevelPageModule);



/***/ }),

/***/ 5670:
/*!*****************************************!*\
  !*** ./src/app/m-level/m-level.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MLevelPage": () => (/* binding */ MLevelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_m_level_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./m-level.page.html */ 7335);
/* harmony import */ var _m_level_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./m-level.page.scss */ 6968);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let MLevelPage = class MLevelPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['m-level1']);
    }
};
MLevelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
MLevelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-m-level',
        template: _raw_loader_m_level_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_m_level_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MLevelPage);



/***/ }),

/***/ 6968:
/*!*******************************************!*\
  !*** ./src/app/m-level/m-level.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('yellow.jpg') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  background: transparent;\n  font-family: Montserrat-SemiBold;\n  font-size: 15px;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E9F673;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.list .row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.list .row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.list .labl {\n  margin-left: 3.5px;\n  margin-right: 3.5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm0tbGV2ZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsZ0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSx1QkFBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUNJO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQUNOOztBQUNJO0VBRUUsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBQU47O0FBRUk7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBRE47O0FBT0U7RUFDRSxhQUFBO0FBSko7O0FBTUU7RUFDRSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUhKOztBQUtFO0VBQ0UseUJBQUE7QUFGSjs7QUFLRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBRko7O0FBS0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUZKOztBQUtFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFGSjs7QUFLRTtFQUNFLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFGSjs7QUFLRTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBRko7O0FBS0U7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNGLHFCQUFBO0FBRkY7O0FBTUU7RUFDQyxnQkFBQTtFQUVDLHVCQUFBO0FBSkoiLCJmaWxlIjoibS1sZXZlbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi9zcmMvYXNzZXRzL1JlY3RhbmdsZSAxODUucG5nXCIpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAgICB1cmwoJy4uLy4uL2Fzc2V0cy9zY3JlZW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICB9XHJcbiAgaW9uLWhlYWRlcntcclxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuLy4uLy4uL2Fzc2V0cy95ZWxsb3cuanBnJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxuXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICBpb24tdG9vbGJhcntcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyMHB4O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcblxyXG4gICAgLnJvd3tcclxuICAgICAgbWFyZ2luLXRvcDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI0U5RjY3MztcclxuICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLnJvdzF7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAucm93MntcclxuXHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IC01cHg7XHJcbiAgICB9XHJcbiAgICAubGFibHtcclxuXHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAzLjVweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAzLjVweDtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb10gKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6ICcnO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIG1hcmdpbjogMCAwLjVlbTtcclxuICB9XHJcbiAgaW5wdXRbdHlwZT1yYWRpb106Y2hlY2tlZCArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0RDMzQ2MTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzEgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucmFkaW8yICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMyArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yb3cze1xyXG4gICAgbWFyZ2luLXRvcDogN3B4O1xyXG4gICAgYmFja2dyb3VuZDogI0U5RjY3MztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiAgLnJvdzR7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRTlGNjczO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG5cclxuICB9XHJcbiAgLmJ0biB7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG5cclxuXHJcbiAgfVxyXG4gIC5yb3c4e1xyXG4gICBtYXJnaW4tdG9wOiAxNXB4O1xyXG5cclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiJdfQ== */");

/***/ }),

/***/ 7335:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/m-level/m-level.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logo2.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n    <ion-row>\n      <img style=\"width: 100%;\" src=\"../../assets/level/m-level.png\" alt=\"\">\n    </ion-row>\n\n    <ion-row  class=\"row1\" >\n      <ion-label  >ALGUNA VEZ HE TENIDO UN ORGASMO?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"mr1\">SI</label>\n        <input id=\"mr1\" type=\"radio\" name=\"group1\" class=\"radio1\" />\n        <label for=\"mr2\">NO</label>\n        <input id=\"mr2\" type=\"radio\" name=\"group1\" class=\"radio2\" />\n        <label for=\"mr3\">NO LO SÉ</label>\n        <input id=\"mr3\" type=\"radio\" name=\"group1\" class=\"radio3\" />\n        <label for=\"mr3\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Sueles hablar de sexo con tu circulo cercano? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"mr4\">SI</label>\n        <input id=\"mr4\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"mr5\">NO</label>\n        <input id=\"mr5\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"mr6\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Sueles hablar de deseos sexuales con tus parejas?   </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"mr7\">SI</label>\n        <input id=\"mr7\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"mr8\">NO</label>\n        <input id=\"mr8\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"mr9\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Cuanto Te gusta el sexo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"mr10\">normal</label>\n        <input id=\"mr10\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"mr11\">mucho Norma</label>\n        <input id=\"mr11\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"mr12\">MUCHO</label>\n        <input id=\"mr12\" type=\"radio\" name=\"group4\" class=\"radio3\" />\n        <label for=\"mr13\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >\tTe gusta hacer el amor con la luz apagada  o con la luz encendida? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"mr14\">Auditiva</label>\n        <input id=\"mr14\" type=\"radio\" name=\"group5\" class=\"radio1\" />\n        <label for=\"mr15\">Visual</label>\n        <input id=\"mr15\" type=\"radio\" name=\"group5\" class=\"radio2\" />\n        <label for=\"mr16\">Sensitiva</label>\n        <input id=\"mr16\" type=\"radio\" name=\"group5\" class=\"radio3\" />\n        <label for=\"mr16\"></label>\n\n\n      </ion-col>\n    </ion-row>\n\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Conoces bien tu cuerpo?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"mr18\">SI</label>\n        <input id=\"mr18\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"mr19\">NO</label>\n        <input id=\"mr19\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"mr20\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" style=\"margin-top: 7px;\">\n      <ion-label  >Has probado a vendar tus ojos para poner a prueba el resto de los sentidos?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"mr21\">SI</label>\n        <input id=\"mr21\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"mr22\">NO</label>\n        <input id=\"mr22\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"mr23\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Eres una persona Romántica, sensual o pasional?</ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"mr24\">ROMANTICA</label>\n        <input id=\"mr24\" type=\"radio\" name=\"group8\" class=\"radio1\" />\n        <label for=\"mr25\">SENSUAL </label>\n        <input id=\"mr25\" type=\"radio\" name=\"group8\" class=\"radio2\" />\n        <label for=\"mr26\">PASIONAL</label>\n        <input id=\"mr26\" type=\"radio\" name=\"group8\" class=\"radio3\" />\n        <label for=\"mr26\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\"   >\n      <ion-label  >Eres mas de hacer el amor?  O el Sexo desenfrenado? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"mr28\">Hacer el amor</label>\n        <input id=\"mr28\" type=\"radio\" name=\"group9\" class=\"radio1\" />\n        <label for=\"mr29\">Sexo desenfrenado </label>\n        <input id=\"mr29\" type=\"radio\" name=\"group9\" class=\"radio2\" />\n        <label for=\"mr29\"></label>\n      </ion-col>\n    </ion-row>\n\n  </ion-list>\n  <ion-list class=\"list1\">\n\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\">FINALIZAR</ion-button>\n    </ion-row>\n  </ion-list>\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_m-level_m-level_module_ts.js.map