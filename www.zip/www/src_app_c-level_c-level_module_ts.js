(self["webpackChunkorgasm"] = self["webpackChunkorgasm"] || []).push([["src_app_c-level_c-level_module_ts"],{

/***/ 3901:
/*!***************************************************!*\
  !*** ./src/app/c-level/c-level-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevelPageRoutingModule": () => (/* binding */ CLevelPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _c_level_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level.page */ 930);




const routes = [
    {
        path: '',
        component: _c_level_page__WEBPACK_IMPORTED_MODULE_0__.CLevelPage
    }
];
let CLevelPageRoutingModule = class CLevelPageRoutingModule {
};
CLevelPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CLevelPageRoutingModule);



/***/ }),

/***/ 7781:
/*!*******************************************!*\
  !*** ./src/app/c-level/c-level.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevelPageModule": () => (/* binding */ CLevelPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _c_level_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./c-level-routing.module */ 3901);
/* harmony import */ var _c_level_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level.page */ 930);







let CLevelPageModule = class CLevelPageModule {
};
CLevelPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _c_level_routing_module__WEBPACK_IMPORTED_MODULE_0__.CLevelPageRoutingModule
        ],
        declarations: [_c_level_page__WEBPACK_IMPORTED_MODULE_1__.CLevelPage]
    })
], CLevelPageModule);



/***/ }),

/***/ 930:
/*!*****************************************!*\
  !*** ./src/app/c-level/c-level.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CLevelPage": () => (/* binding */ CLevelPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_c_level_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./c-level.page.html */ 7631);
/* harmony import */ var _c_level_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./c-level.page.scss */ 9746);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/alertcontroller.service */ 5984);






let CLevelPage = class CLevelPage {
    constructor(router, alert1) {
        this.router = router;
        this.alert1 = alert1;
    }
    ngOnInit() {
    }
    goto() {
        this.router.navigate(['c-level1']);
    }
};
CLevelPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_alertcontroller_service__WEBPACK_IMPORTED_MODULE_2__.AlertcontrollerService }
];
CLevelPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-c-level',
        template: _raw_loader_c_level_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_c_level_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CLevelPage);



/***/ }),

/***/ 9746:
/*!*******************************************!*\
  !*** ./src/app/c-level/c-level.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: url('screen.png') no-repeat center center / cover;\n  font-family: Montserrat-SemiBold;\n}\n\nion-header {\n  background: #fff url('yellow.jpg') no-repeat center center/cover;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\nion-toolbar {\n  --background: transparent;\n  height: 80px;\n  border-bottom-left-radius: 20px;\n  border-bottom-right-radius: 20px;\n}\n\n.list {\n  font-size: 15px;\n  font-family: Montserrat-SemiBold;\n  background: transparent;\n}\n\n.list .row {\n  margin-top: 12px;\n  background: #E9F673;\n  height: 35px;\n  font-size: 22px;\n  justify-content: center;\n  align-items: center;\n}\n\n.lis2 {\n  background: #E9F673;\n}\n\n.row1 {\n  text-align: center;\n  justify-content: center;\n}\n\n.row2 {\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\ninput[type=radio] {\n  display: none;\n}\n\ninput[type=radio] + label::before {\n  content: \"\";\n  display: inline-block;\n  border: 1px solid #000;\n  border-radius: 50%;\n  margin: 0 0.5em;\n}\n\ninput[type=radio]:checked + label::before {\n  background-color: #DC3461;\n}\n\n.radio1 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio2 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.radio3 + label::before {\n  width: 0.5em;\n  height: 0.5em;\n}\n\n.row3 {\n  margin-top: 7px;\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n}\n\n.row4 {\n  background: #E9F673;\n  text-align: center;\n  justify-content: center;\n  margin-top: -5px;\n}\n\n.btn {\n  width: 150px;\n  height: 30px;\n  --background: #DC3461;\n}\n\n.row8 {\n  margin-top: 15px;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImMtbGV2ZWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksK0RBQUE7RUFFQSxnQ0FBQTtBQURKOztBQUdFO0VBQ0UsZ0VBQUE7RUFFQSwrQkFBQTtFQUNDLGdDQUFBO0FBREw7O0FBR0U7RUFDRSx5QkFBQTtFQUNBLFlBQUE7RUFDQSwrQkFBQTtFQUNDLGdDQUFBO0FBQUw7O0FBRUU7RUFDRSxlQUFBO0VBQ0EsZ0NBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUNJO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNOOztBQUVBO0VBQ0ksbUJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFFRTtFQUVFLGtCQUFBO0VBQ0EsdUJBQUE7RUFFQSxnQkFBQTtBQURKOztBQUtFO0VBQ0UsYUFBQTtBQUZKOztBQUlFO0VBQ0UsV0FBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFESjs7QUFHRTtFQUNFLHlCQUFBO0FBQUo7O0FBR0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUFKOztBQUdFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFBSjs7QUFHRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBQUo7O0FBSUU7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFFQSxnQkFBQTtBQUZKOztBQUtFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDRixxQkFBQTtBQUZGOztBQU1FO0VBQ0MsZ0JBQUE7RUFFQyx1QkFBQTtBQUpKIiwiZmlsZSI6ImMtbGV2ZWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAvL2JhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vc3JjL2Fzc2V0cy9SZWN0YW5nbGUgMTg1LnBuZ1wiKTtcclxuICAgIC0tYmFja2dyb3VuZDogICAgdXJsKCcuLi8uLi9hc3NldHMvc2NyZWVuLnBuZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQtU2VtaUJvbGQ7XHJcbiAgfVxyXG4gIGlvbi1oZWFkZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmIHVybCgnLi8uLi8uLi9hc3NldHMveWVsbG93LmpwZycpIG5vLXJlcGVhdCBjZW50ZXIgY2VudGVyIC8gY292ZXI7XHJcblxyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgaW9uLXRvb2xiYXJ7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjBweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjBweDtcclxuICB9XHJcbiAgLmxpc3R7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBmb250LWZhbWlseTogTW9udHNlcnJhdC1TZW1pQm9sZDtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgIC5yb3d7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgZm9udC1zaXplOiAyMnB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG4ubGlzMntcclxuICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbn1cclxuXHJcbi5yb3cxe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAucm93MntcclxuXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gIH1cclxuXHJcblxyXG4gIGlucHV0W3R5cGU9cmFkaW9dIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXJnaW46IDAgMC41ZW07XHJcbiAgfVxyXG4gIGlucHV0W3R5cGU9cmFkaW9dOmNoZWNrZWQgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEQzM0NjE7XHJcbiAgfVxyXG5cclxuICAucmFkaW8xICsgbGFiZWw6OmJlZm9yZSB7XHJcbiAgICB3aWR0aDogMC41ZW07XHJcbiAgICBoZWlnaHQ6IDAuNWVtO1xyXG4gIH1cclxuXHJcbiAgLnJhZGlvMiArIGxhYmVsOjpiZWZvcmUge1xyXG4gICAgd2lkdGg6IDAuNWVtO1xyXG4gICAgaGVpZ2h0OiAwLjVlbTtcclxuICB9XHJcblxyXG4gIC5yYWRpbzMgKyBsYWJlbDo6YmVmb3JlIHtcclxuICAgIHdpZHRoOiAwLjVlbTtcclxuICAgIGhlaWdodDogMC41ZW07XHJcbiAgfVxyXG5cclxuICAucm93M3tcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxuICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcblxyXG4gIH1cclxuICAucm93NHtcclxuICAgIGJhY2tncm91bmQ6ICNFOUY2NzM7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHJcbiAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG5cclxuICB9XHJcbiAgLmJ0biB7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjREMzNDYxO1xyXG5cclxuXHJcbiAgfVxyXG4gIC5yb3c4e1xyXG4gICBtYXJnaW4tdG9wOiAxNXB4O1xyXG5cclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICB9XHJcbiJdfQ== */");

/***/ }),

/***/ 7631:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/c-level/c-level.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header >\n    <ion-toolbar>\n      <ion-list style=\"text-align: center;background: transparent;\">\n        <img  src=\"../../assets/logo/logo2.svg\" alt=\"\">\n      </ion-list>\n      <ion-buttons slot=\"end\">\n        <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <img style=\"position: absolute; bottom: 0; right: 0; margin: 10px;\" src=\"../../assets/inbox.svg\" alt=\"\">\n  </ion-header>\n  <ion-list class=\"list\">\n\n    <ion-row class=\"row\" >\n      <ion-label>Conozcámonos un poco!</ion-label>\n    </ion-row>\n     <ion-row>\n   <img style=\"width: 100%;\" src=\"../../assets/level/couple1.png\" alt=\"\">\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Has probado a vendar tus ojos para poner a prueba el resto de los sentidos? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"cr1\">SI</label>\n        <input id=\"cr1\" type=\"radio\" name=\"group551\" class=\"radio1\" />\n        <label for=\"cr2\">NO</label>\n        <input id=\"cr2\" type=\"radio\" name=\"group551\" class=\"radio2\" />\n        <label for=\"cr3\">Te gusta</label>\n        <input id=\"cr3\" type=\"radio\" name=\"group551\" class=\"radio3\" />\n        <label for=\"cr3\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Conoces bien tu cuerpo? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"cr4\">SI</label>\n        <input id=\"cr4\" type=\"radio\" name=\"group2\" class=\"radio1\" />\n        <label for=\"cr5\">NO</label>\n        <input id=\"cr5\" type=\"radio\" name=\"group2\" class=\"radio2\" />\n        <label for=\"cr5\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Te has masturbado alguna vez?  </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"cq1\">SI</label>\n        <input id=\"cq1\" type=\"radio\" name=\"group3\" class=\"radio1\" />\n        <label for=\"cq2\">NO</label>\n        <input id=\"cq2\" type=\"radio\" name=\"group3\" class=\"radio2\" />\n        <label for=\"cq2\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Sabes como recibir placer? </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"cw4\">SI</label>\n        <input id=\"cw4\" type=\"radio\" name=\"group4\" class=\"radio1\" />\n        <label for=\"cw5\">NO</label>\n        <input id=\"cw5\" type=\"radio\" name=\"group4\" class=\"radio2\" />\n        <label for=\"cw5\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row1\" >\n      <ion-label  >Eres Visual, Auditiva, o Kinestésica (sensitiva)?   </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row2\">\n      <ion-col >\n        <label for=\"ce1\">Visual</label>\n        <input id=\"ce1\" type=\"radio\" name=\"group6\" class=\"radio1\" />\n        <label for=\"ce2\">Auditiva</label>\n        <input id=\"ce2\" type=\"radio\" name=\"group6\" class=\"radio2\" />\n        <label for=\"ce3\">Sensitiva</label>\n        <input id=\"ce3\" type=\"radio\" name=\"group6\" class=\"radio3\" />\n        <label for=\"ce3\"></label>\n      </ion-col>\n    </ion-row>\n    <ion-row  class=\"row3\"   >\n      <ion-label  >Te gusta que te exciten con palabras?   </ion-label>\n\n    </ion-row>\n    <ion-row class=\"row4\">\n      <ion-col >\n        <label for=\"ca4\">SI</label>\n        <input id=\"ca4\" type=\"radio\" name=\"group7\" class=\"radio1\" />\n        <label for=\"ca5\">NO</label>\n        <input id=\"ca5\" type=\"radio\" name=\"group7\" class=\"radio2\" />\n        <label for=\"ca5\"></label>\n      </ion-col>\n    </ion-row>\n\n    <ion-row class=\"row8\">\n\n      <ion-button class=\"btn\" shape=\"round\" (click)=\"goto()\" >SIGUIENTE</ion-button>\n    </ion-row>\n    </ion-list>\n    </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_c-level_c-level_module_ts.js.map